import requests as rq
from bs4 import BeautifulSoup as bs

url = "http://lacnic.net/cgi-bin/lacnic/whois?lg=EN"
ip = raw_input("Please enter the fuck ip: ")
data = {
    "query":ip
}

r = rq.post(url, data = data)

html = bs(r.content,"html.parser")
dat = html.find("pre").text
print dat
