#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests as re
from bs4 import BeautifulSoup
import os
import time

url = "https://www.exploit-db.com/papers/?order_by=date_published&order=desc&pg="
print "[+] Conectando con "+url
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
i = 1
var = 0
ext = ""
car =""

def write(final,file):
    with open(final, 'wb') as f:
        f.write(file.content)
    

def download(file,description,ext,car,lang):
    time.sleep(2)
    
    ruta = r"files/"+car+"/"+lang+"/"
    name = description+ext
    final = ruta + name
    
    if ext ==".txt":
        if not os.path.exists(ruta):
            os.makedirs(ruta)
            write(final,file)
        else:
            write(final,file)
            
    elif ext == ".pdf":
        if not os.path.exists(ruta): 
            os.makedirs(ruta)
            write(final,file)
        else:
            write(final,file)
    else:
        if not os.path.exists(ruta): 
            os.makedirs(ruta)
            write(final,file)
        else:
            write(final,file)




for i in range(2,50):
    i = i + 1

    p = url+str(i)
    r = re.get(p, timeout=None, verify=False, headers=headers)
    time.sleep(2)
    s = BeautifulSoup(r.content, "html.parser")
    for tabla in s.find_all("tbody"):
        
        for tr in tabla.find_all("tr"):
            for description in tr.find_all("td", {"class":"description"}):
                var = var + 1
                
                for dlink in tr.find_all("td",{"class":"dlink"}):
                    for link in dlink.find_all("a", href=True):
                        url = link['href']
                        if url[-4:]==".pdf":
                            ext = ".pdf"
                            car = "pdf"
                        elif url[-5:] ==".docx":
                            ext = ".docx"
                            car = "docs"
                        else:
                            ext = ".txt"
                            car = "txt"
                            
                        for date in tr.find_all("td",{"class":"date"}):
                            for language in tr.find_all("td",{"class":"language"}):
                                lang = language.text.strip()
                                for author in tr.find_all("td",{"class":"author"}):
                                    
                                    print "Name:\t"+description.text.strip()
                                    print "Autor:\t"+author.text.strip()
                                    print "Lang:\t"+lang
                                    print "Date:\t"+date.text
                                    print "Links:\t"+url
                                    file = re.get(url, headers=headers, verify=False, timeout=None)
                                    download(file,description.text.strip().replace("/","-").replace(".","-"),ext,car,lang)
                                    print p
                                    print "////////////////////////////////////////////////////"
                
        
                
                
print "Termine perra con %s links de papers "%var