# -*- coding: utf-8 -*-
import urllib
import requests as rq
from bs4 import BeautifulSoup as bs
import time
import json
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()

f = open("grac.txt","wb")

url = "http://www.biography.com/search?query=grace%20hopper"
r = rq.get(url)
html = bs(r.content, "html.parser")
for people in html.find("script",{"id":"pageItemData"}).findNext("script").findNext("script"): #,{"class":"ng-binding ng-scope"}
    #res = json.dumps(people)
    res =json.loads(people)
    l =  res["collection"]["items"]
    f.write(str(l))
    print l
    
