"""


"""


'''
def PatternCount(text, pattern):
    tlen = len(text)
    plen = len(pattern)
    Count = [0] * (tlen - plen + 1)

    for i in range(tlen):
        if text[i:i + plen] == pattern:
            Count[i] = text.count(pattern)

    return Count
'''


def PatternCount(text, pattern):
    # return text.count(pattern)
    pat_count = 0
    for i in range(len(text) - len(pattern) + 1):
        if text[i: (i + len(pattern))] == pattern:
            pat_count += 1
    return pat_count


def FrequentWords(Text, k):
    Count = [0] * (len(Text) - k + 1)
    FrequentPatterns = []
    for i in range(0, len(Text) - k + 1):
        pattern = Text[i:i + k]
        Count[i] = PatternCount(Text, pattern)
        # print(Count[i], Text.count(pattern))

    maxCount = max(Count)
    for i in range(0, len(Text) - k + 1):
        if Count[i] == maxCount:
            FrequentPatterns.append(Text[i:(i + k)])

    fp = set(FrequentPatterns)
    return fp


def occurrence(string, substring):
    count = 0
    for x in range(len(string) - len(substring) + 1):
        if string[x:x + len(substring)] == substring:
            count += 1
        # end if
    # end for
    return count


def pattern(seq, n):
    max_count = 0
    pat_list = seq.split(" ")
    for pat in pat_list:
        if len(pat) == n:
            count = occurrence(seq, pat)
            if count > max_count:
                max_count = count
                ThePat = pat
            # end if
        # end if
    # end for

    return ThePat, max_count


seq = "the quick brown fox jumped over the lazy dog"
occurrence = pattern(seq, 3)
print("pattern with most occurrence = {}, occurrences = {}.".format(occurrence[0], occurrence[1]))

text = "ACTGACTCCCACCCC"
print(FrequentWords(text, 3))
