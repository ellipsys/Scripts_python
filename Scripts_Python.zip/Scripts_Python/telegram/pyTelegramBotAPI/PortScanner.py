import optparse
import   socket
from socket import *

def connScan(tgtHost, tgtPort):
    try:
         connSkt = socket(AF_INET, SOCK_STREAM)
         connSkt.connect((tgtHost, tgtPort))
         connSkt.send('Hi')
         results = connSkt.recv(100)
         print '[+]%d/tcp open'% tgtPort
         print '[+] ' + str(results)
         connSkt.close()
    except:
         print '[-]%d/tcp closed'% tgtPort


def portScan(tgtHost, tgtPort):
   try:
         tgtIP = gethostbyname(tgtHost)
   except:
         print "[-] Cannot resolve '%s': Unknown host"%tgtHost
         return
   try:
         tgtName = gethostbyaddr(tgtIP)
         print '\n[+] Scan Results for: ' + tgtName[0]
   except:
         print '\n[+] Scan Results for: ' + tgtIP
         setdefaulttimeout(1)
   
   print 'Scanning port ' + str(tgtPort)
   connScan(tgtHost, int(tgtPort))



def main():

	parser = optparse.OptionParser('usage %prog -H ' +  '<target host> -p <target port>')
	parser.add_option('-H' , dest='tgtHost', type='string' ,  help='specify target host')
	parser.add_option('-p' , dest='tgtPort', type='int' ,  help='specify target port')
	
	(options, args) = parser.parse_args()
	tgtHost=options.tgtHost
	tgtPort=options.tgtPort
	if (tgtHost == None) | (tgtPort==None):
	       print parser.usage
               exit(0)
        portScan(tgtHost, tgtPort)

main()
