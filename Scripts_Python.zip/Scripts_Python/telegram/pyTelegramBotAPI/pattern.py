# -*- coding: cp1252 -*-
# Buscador de patron a partir de lectura del archivo gesture.key
#Requiere que tengamos en la misma ruta guardado el archivo AndroidGestureSHA1.txt
# y el archivo gesture.key
# By P0et

pat = open('gesture.key','rb')
patron = pat.read()
pattern = patron.encode('hex')
patron = pattern.upper()
print 'El valor obtenido de gesture.key en hexa es: '
print patron
print
encontrado = 'N'
val = open('AndroidGestureSHA1.txt','rb')

while (encontrado=='N'):

   value = val.readline()
   if value.find(patron)>0:
       encontrado='S'
       print 'El patron buscado es: ',value
       raw_input()
   else:
       encontrado='N'

