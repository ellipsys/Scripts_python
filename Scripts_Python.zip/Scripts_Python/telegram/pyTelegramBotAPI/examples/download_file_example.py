import telebot

TOKEN = '283782883:AAGL26hkLIPYI_6WR62Yq4sU7rtsDPUIPXo'
CHAT_ID = '@ellipsys'

bot = telebot.TeleBot(TOKEN)

ret_msg = bot.send_voice(CHAT_ID, open('tests/test_data/record.ogg'))

file_info = bot.get_file(ret_msg.voice.file_id)

downloaded_file = bot.download_file(file_info.file_path)

with open('new_file.ogg', 'wb') as new_file:
    new_file.write(downloaded_file)
