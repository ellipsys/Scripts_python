import mechanize
from bs4 import BeautifulSoup

def testProxy(url, proxy):
      browser = mechanize.Browser()
      browser.set_proxies(proxy)
      try:
        page = browser.open(url)
        source_code = page.read()
        print 'proxy works!'
      except:
        print 'proxy doesnt work'

browser = mechanize.Browser()
page = browser.open('http://proxy-list.org/spanish/index.php')
source_code = page.read()
#print source_code

soup = BeautifulSoup(source_code)
cla = soup.findAll('li')
pro = open('proxies.txt','a')

i = 0      
for cla in soup.findAll('li', {"class":"proxy"}):

          
          proxy = str(cla.findAll(text=True))
          if i > 0:
                uproxy = proxy.replace("u","")
                cproxy = uproxy.replace("'","")
                oproxy = cproxy.replace("[","")
                nproxy = oproxy.replace("]","")
                pro.write(nproxy)
                pro.write('\n')
                
          i = i + 1
          
       

pro.close()
        
url = 'http://www.cual-es-mi-ip.net/'
pro_r = open('proxies.txt','r')
show_p = pro_r.read()
print 'Proxies disponibles: '
print show_p
pro_r.close()
uproxy = raw_input('Ingrese proxy en la  forma ip:puerto ')
hideMeProxy = {'http': uproxy}
testProxy(url, hideMeProxy)
