# -*- coding: utf-8 -*-
import telebot
from telebot import types
import os
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()

API_TOKEN = '309837538:AAE5cfDHq3CrJu4L4c3_8oxDboShZRNA0G0'
bot = telebot.TeleBot(API_TOKEN)
chat_id = ''

print "[+] Ok estoy esperando mi señor"
command = ['test']
@bot.message_handler(commands=command)
def cmd(message):
    chat_id = message.chat.id
    markup = types.ReplyKeyboardMarkup(one_time_keyboard=True)
    markup.add('Male', 'Female')
    msg = bot.reply_to(message, 'What is your gender', reply_markup=markup)
    
bot.polling()
    