# -*- coding: utf-8 -*-
import telebot
from telebot import types
import os
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()

API_TOKEN = '309837538:AAE5cfDHq3CrJu4L4c3_8oxDboShZRNA0G0'
bot = telebot.TeleBot(API_TOKEN)
chat_id = ''

print "[+] Ok estoy esperando mi señor"
command = ['exec','ejec','cmd','terminal']
@bot.message_handler(commands=command)
def cmd(message):
    chat_id = message.chat.id
    msg = bot.send_message(chat_id, """Que comando vas a ejecutar?
Te recuerdo que para algunos comandos necesitas ser root \xF0\x9F\x98\x9C \xF0\x9F\x98\x9C
    """)
    bot.register_next_step_handler(msg, execute)

def execute(message):
    try:
        chat_id = message.chat.id
        comando = str(message.text)
        msg = str( """
        Estoy trabajando en ello baby \xF0\x9F\x98\x8A
Ejecutando 
$%s
        """%(comando))
        print "Ejecutando el comando %s"%(comando)
        print comando
        bot.send_message(chat_id,msg)
        try:
            if comando.startswith( 'wget ' ):
                l = open(os.system("%s"%(comando)), 'rb')
                #l = open(l, 'rb')
                doc = "Descarga completa"
                bot.send_document(chat_id,l)
            elif comando.startswith("mkdir "):
                doc = "Carpeta creada"
                os.system("%s"%(comando))
                bot.send_message(chat_id,doc,disable_web_page_preview=None)
            elif comando.startswith("sudo msfconsole") or ('msfconsole' in comando):
                doc = "No puedo ejecutar el grandioso Metasploit sorry \xF0\x9F\x98\xA5 \xF0\x9F\x98\xA5 \xF0\x9F\x98\xA5"
                bot.send_message(chat_id,doc,disable_web_page_preview=None)
            elif comando.startswith("rm "):
                doc = "Archivo eliminado"
                os.system("%s"%(comando))
                bot.send_message(chat_id,doc,disable_web_page_preview=None)
            elif comando.startswith("cd "):
                doc = "Ok te moviste de carpeta"
                os.system("%s"%(comando))
                bot.send_message(chat_id,doc,disable_web_page_preview=None)
            elif comando.startswith("get "):
                comando = comando.replace("get ","")
                doc = open(comando, "rb")
                bot.send_document(chat_id,doc)
            elif comando.startswith('whois'):
                os.system("%s > whois.txt"%(comando))
                doc = open("whois.txt","rb")
                bot.send_message(chat_id,'Ok aqui va \xF0\x9F\x98\x9A',disable_web_page_preview=None)
                bot.send_document(chat_id, doc)
                os.system("rm -fr whois.txt")
            elif comando == 'sudo apt-get update':
                os.system("sudo apt-get update && echo 'y' | sudo apt-get upgrade")
                bot.send_message(chat_id,'Ok el sistema ha sido actualizado',disable_web_page_preview=None)
            elif 'nmap' in comando:
                os.system("%s -oN nmap.txt"%(comando))
                doc = open("nmap.txt","rb").read()
                bot.send_message(chat_id,'Resultado de nmap',disable_web_page_preview=None)
                bot.send_message(chat_id, doc)
                os.system("rm -fr nmap.txt")
            elif comando.startswith("/"):
                doc ="Nep, no puedo ejecutar eso \xF0\x9F\x98\xA5 \xF0\x9F\x98\xA5 \xF0\x9F\x98\xA5"
                bot.send_message(chat_id,doc,disable_web_page_preview=None)
                
            else:    
                os.system("%s > cmd.txt"%(comando))
                doc = open("cmd.txt","rb").read()
                bot.send_message(chat_id,doc,disable_web_page_preview=None)
                os.system("rm -fr cmd.txt")
                os.system("clear")
                bot.send_message(chat_id,"Listo, feliz? \xF0\x9F\x98\x83",disable_web_page_preview=None)
        except:
            msg = '''[+] Ocurrio un error ejecuando %s
Talvez escribiste mal o necesita permisos de root
\xF0\x9F\x98\x93 \xF0\x9F\x98\x93'''%comando
            bot.send_message(chat_id,msg)
    except Exception as e:
        bot.reply_to(message, '[+] Algo salio mal')

        
    print "Termine de ejecutar el comando %s"%(comando)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    msg=open("start.txt").read()
    chat_id = message.chat.id
    bot.send_message(chat_id,msg)
    
@bot.message_handler(commands=['music'])
def audio(message):
    msg=open("Me llamas.mp3","rb")
    chat_id = message.chat.id
    bot.send_chat_action(chat_id, 'find_location')
    bot.send_audio(chat_id,msg)
    bot.send_message(chat_id,"Espero te guste")
    
@bot.message_handler(commands=["speech"])
def speach(message):
    chat_id = message.chat.id
    msg = bot.send_message(chat_id,"Please write the text")
    bot.register_next_step_handler(msg, voice)

def voice(message):
    
    print message.text
    texto = message.text.encode('utf-8')
    chat_id = message.chat.id
    #\"%s\"
        
    os.system("python voice.py \"%s\""%(texto))
    audio = open("voice.mp3","rb")
    bot.send_chat_action(chat_id,'find_location')
    bot.send_audio(chat_id,audio)
    bot.send_message(chat_id,"Ok tu lo pediste")
    os.system("rm -fr voice.mp3")
    
@bot.message_handler(commands=["file"])
def writ(message):
    chat_id = message.chat.id
    bot.send_message(chat_id,"Enter name of file")
    name = message.text
    os.system("echo %s"%(name))
    #bot.register_next_step_handler(name, writing)

    
"""
@bot.message_handler(regexp="")
def handle_message(message):
    
    chat_id = message.chat.id
    msg = "Hola Que quieres? \xF0\x9F\x98\x85 \xF0\x9F\x98\x85"
    bot.send_message(chat_id,msg)
    

    

def process_age_step(message):
    try:
        chat_id = message.chat.id
        age = message.text
        if not age.isdigit():
            msg = bot.reply_to(message, 'Age should be a number. How old are you?')
            bot.register_next_step_handler(msg, process_age_step)
            return
        user = user_dict[chat_id]
        user.age = age
        markup = types.ReplyKeyboardMarkup(one_time_keyboard=True)
        markup.add('Male', 'Female')
        msg = bot.reply_to(message, 'What is your gender', reply_markup=markup)
        bot.register_next_step_handler(msg, process_sex_step)
    except Exception as e:
        bot.reply_to(message, 'oooops')


def process_sex_step(message):
    try:
        chat_id = message.chat.id
        sex = message.text
        user = user_dict[chat_id]
        if (sex == u'Male') or (sex == u'Female'):
            user.sex = sex
        else:
            raise Exception()
        bot.send_message(chat_id, 'Nice to meet you ' + user.name + '\n Age:' + str(user.age) + '\n Sex:' + user.sex)
    except Exception as e:
        bot.reply_to(message, 'oooops')
"""

bot.polling()