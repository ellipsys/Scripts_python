
import telebot
from telebot import *
import os
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()


token = "309837538:AAE5cfDHq3CrJu4L4c3_8oxDboShZRNA0G0"
bot = telebot.TeleBot(token)
chat_id = "222587238" #chat_id = message.chat.id
#http://apps.timwhitlock.info/emoji/tables/unicode#block-6b-additional-transport-and-map-symbols

@bot.message_handler(commands=['help', 'start', 'hola'])
def send_welcome(message):
    bot.reply_to(message, """\
Hi there, I am Ellipsys_Bot.
I am here to serve you master!
I'm running baby ;)\
""")
    
@bot.message_handler(commands=['test'])
def emoji(message):
    
    """
    bot.reply_to(message, "\xF0\x9F\x98\x9A \xF0\x9F\x98\x8D")
    """
    markup = types.ReplyKeyboardMarkup(one_time_keyboard=True)
    markup.add('Male', 'Female', 'Undefined')
    bot.send_message(message, 'What is your gender', reply_markup=markup)
    
    

@bot.message_handler(commands=['ls'])
def ls(message):
    os.system('ls > ls.txt')
    doc = open('ls.txt','rb')
    doc = doc.read()
    bot.send_message(message,doc)
    os.system("rm -fr ls.txt")
    
@bot.message_handler(commands=['pwd'])
def pwd(message):
    os.system('pwd > pwd.txt')
    doc = open('pwd.txt','rb')
    doc = doc.read()
    bot.reply_to(message,doc)
    os.system("rm -fr pwd.txt")

@bot.message_handler(commands=['tree'])
def tree(message):
    os.system('tree > tree.txt')
    doc = open('tree.txt','rb').read()
    #doc = doc.read()
    bot.reply_to(message,doc)
    os.system("rm -fr tree.txt")
    
@bot.message_handler(regexp='o')
def handle_docs_audio(message):
    bot.reply_to(message,"Cierto \xF0\x9F\x98\x8D")
    

@bot.message_handler(commands=['p'])
def enviar_doc(message):
    os.system('ls .. > ls.txt')
    doc = open('ls.txt','rb')
    bot.send_document(chat_id, doc) #esto envia como documento con la opcion descargar

@bot.message_handler(commands=['cd ..'])
def namp(message):
    os.system('cd .. > cd.txt')
    doc = open('cd.txt','rb')
    doc = doc.read()
    bot.reply_to(message,doc)
    os.system("rm -fr cd.txt")


    

bot.polling(none_stop=False, interval=0)    
