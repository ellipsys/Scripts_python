import telebot
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()

API_TOKEN = "283782883:AAGL26hkLIPYI_6WR62Yq4sU7rtsDPUIPXo"#'<api_token>'

bot = telebot.TeleBot(API_TOKEN)
print "Ok i'm running baby"
#chat_id = "222587238"

@bot.message_handler(commands=['help', 'start', 'hola'])
def send_welcome(message):
    bot.reply_to(message, """\
Hi there, I am Ellipsys_Bot.
I am here to serve you master!
I'm running baby ;)\
""")
    print "here"
    


# Handle all other messages with content_type 'text' (content_types defaults to ['text'])
@bot.message_handler(func=lambda message: True)
def echo_message(message):
    bot.reply_to(message, message.text)

bot.polling()
