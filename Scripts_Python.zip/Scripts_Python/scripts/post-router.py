# -*- coding: utf-8 -*-
import requests
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup
import time

def main():
    s = requests.Session()
    
    headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
    data = {
        "username":"admin",
        "password":"Uq-4GIt3M",
        "PrimaryNetworkEnable" : "0"

    }
    #('http://'+ip+':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=None)
    #data={'number': 12524, 'type': 'issue', 'action': 'show'}
  
    t=requests.post('http://186.87.137.93:8080/goform/wlanPrimaryNetwork?5G', timeout= None, verify=False, data=data, headers=headers)
    #/goform/wlanPrimaryNetwork?5G
    
    
    print t
    print t.status_code
    print t.cookies
    
main()
    
    
    
