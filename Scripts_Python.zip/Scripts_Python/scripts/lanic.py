import requests as rq
from bs4 import BeautifulSoup as bs

url = "http://lacnic.net/cgi-bin/lacnic/whois?lg=EN"
data = {
    "query":"200.116.62.31"
}

r = rq.post(url, data = data)

html = bs(r.content,"html.parser")
dat = html.find("pre").text
print dat