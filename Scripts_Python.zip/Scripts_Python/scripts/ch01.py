xx = raw_input('Select the shells file:')
fo = open(xx,'r')
xxx = fo.readlines(999)
live = open('shells.txt','w+')
for line in xxx:
   r = requests.get(line,allow_redirects=False,timeout=9999969)
   if r.ok == True:
	   print('%s ==> This shell is dead !'%line.rstrip())
   live.writelines("%s\n"%line)
   if r.ok == False:
	   print('%s ==> This shell works fine !'%line.rstrip())
print colored("You'll find your working shells in shells.txt","green")