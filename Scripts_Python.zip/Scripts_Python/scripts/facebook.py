import requests as rq
from bs4 import BeautifulSoup as bs
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()

headers = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 6.1; de; rv:1.9.2.3) Gecko/20121221 Firefox/3.6.8'}
data = {"email":"eliseo.torres95@gmail.com"}
r = rq.post("https://www.facebook.com/login/identify?ctx=recover&lwv=301", verify=False, headers=headers, data=data)
# https://www.facebook.com/ajax/login/help/identify.php?ctx=recover
b = bs(r.content, "html.parser")
print r.content
texto = open("html.txt","wb")
#print r.headers
texto.write(str(r.content))
for name in b.findAll("input",{"":"inputtext"}):
    print name