import requests
#r = requests.post('http://httpbin.org/post', files=dict(foo='bar'))
r = requests.get("http://aulanet.umb.edu.co/aulanet_jh/principal.php/edita_datos_con_chat/login.php")
print r.status_code
print r.content

#http://aulanet.umb.edu.co/aulanet_jh/edita_datos/editar_datos.php?codigo=96100709780&random=275348&nestcape=1
#http://aulanet.umb.edu.co/aulanet_jh/principal.php/edita_datos_con_chat/login.php
#view-source:http://aulanet.umb.edu.co/aulanet_jh/vinculos.php?codigo=am9hbmR1MTE4MDgwdW1iMTAwNzM5NjI2OGpvYW5kdTExODA4MHVtYg==&color=negro.jpg

