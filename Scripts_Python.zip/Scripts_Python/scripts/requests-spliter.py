from splinter.browser import Browser
br = Browser('chrome')
url= "http://181.129.126.217/lang/device.res"
user = "admin"
password = "Q3BlMDRFcG0="

br.visit(url)

br.fill("Username", user)
br.fill("Password", password)