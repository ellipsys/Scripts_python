#!/usr/bin/env python
# -*- coding: utf-8 -*-

import requests
import json
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings()


username = "ellipsys95"
password = "5w0rdf15h"

       
data = '{{"username": "{}", "password": "{}"}}'.format(username,password)
r = requests.post("https://api.zoomeye.org/user/login",data=data, verify=False)
token = r.json().get('access_token') 
headers = {'Authorization': 'JWT %s' % token}
search = "https://api.zoomeye.org/host/search?query=country:co%20port:8080&WWW-Authenticate&page=1"
info = "https://api.zoomeye.org/resources-info"
rq = requests.get(info,headers=headers)
rq_search = requests.get(search,headers=headers)
matches = rq_search.json().get('matches')
total = rq_search.json().get('total')
file = open("claro.txt","wb")

print total
print rq_search.status_code
page = (total/10)



for i in range(page):
    search = "https://api.zoomeye.org/host/search?query=country:co%20RomPager&page={}".format(i+1)
    q = requests.get(search,headers=headers)
    s = q.json().get('matches')

    for ip in s:
        print ip['ip']
        file.write(str(ip['ip'])+'\n')
        
        
        
file.close()

    
