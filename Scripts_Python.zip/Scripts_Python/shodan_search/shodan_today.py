import requests as rq
from netaddr import *
from bs4 import BeautifulSoup
from requests.auth import HTTPBasicAuth
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()
global user, password

user = "ellipsys"
password = "5w0rdf15h"
url = "https://www.shodan.io/search?query=country%3ACO&page=3"
q = {
    'query':'country:co'
}
i = 1
s = rq.Session()


r = s.get(url,auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
print r.text
html = BeautifulSoup(r.content, "html.parser")
for data in html.findAll("div",{"class":"ip"}):
    print data