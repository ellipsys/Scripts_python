import requests as rq
from netaddr import *
from bs4 import BeautifulSoup
from requests.auth import HTTPBasicAuth
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()
global user, password
from urlparse import *

user = "ellipsys"
password = "5w0rdf15h"
file = open("shodan.txt","wb")

url = "https://www.shodan.io/explore/recent?page="
i = 1

while True:
    r = rq.get(url+str(i),auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
    html = BeautifulSoup(r.content, "html.parser")
    #print "pagina "+str(i)
    if i == 21:
        break
    
        
    
    for search in html.find("div",{"class":"span8 browse-queries browse-queries-large"}).findAll("a"):
        link = str("https://www.shodan.io"+search["href"])
        if not "/explore/recent?page" in link:
            print link
            file.write(link+"\n")
            #print str(i)
        else:
            pass
            
        
        
    i = i + 1
        
    
    