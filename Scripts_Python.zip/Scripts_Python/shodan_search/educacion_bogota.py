import requests as rq
from netaddr import *
from bs4 import BeautifulSoup
from urlparse import *

url = "http://matriculabd1.redp.edu.co/sistemat02/sed/websubsidios/HORUS/resultados_2017/check_list.asp"
headers = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 6.1; de; rv:1.9.2.3) Gecko/20121221 Firefox/3.6.8'}
#r = rq.get(url)

i = 88468
while True:
    
    data = {
        "radicado":"{}".format(str(i))
    }
    #print i
    r = rq.post(url, data = data, headers=headers)
    html = BeautifulSoup(r.content, "html.parser")
    code =  str(r.status_code)
    #print i
    for dat in html.find("p",{"align":"justify"}):
    
        
        try:
                
            print dat.string.split(":")[1] + ", %s"%(i)
                
            
        except:
            pass

            
    i = i + 1