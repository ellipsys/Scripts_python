import requests as rq
from netaddr import *
from bs4 import BeautifulSoup as bs
from urlparse import *

url = "http://matriculabd1.redp.edu.co/sistemat02/sed/websubsidios/HORUS/resultados_2017/check_list.asp"
headers = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 6.1; de; rv:1.9.2.3) Gecko/20121221 Firefox/3.6.8'}
#r = rq.get(url)
def post():
    url="http://matriculabd1.redp.edu.co/sistemat02/sed/websubsidios/HORUS/Actas/stcae/acta.asp"
    data = {
        "name1":"ellipsys",
        "name2":"ellipsys",
        "apel1":"ellipsys",
        "apel2":"ellipsys",
        "nare1":"ellipsys",
        "nare2":"ellipsys",
        "apre1":"ellipsys",
        "apre2":"ellipsys",
    }
    r = rq.post(url,data=data)

    #../Actas/stcae/validar.asp
    
def validar(a):
    
    data = {
        "nuid":"{}".format(str(a)),
        "ties":"3"
    }
    
    url = "http://matriculabd1.redp.edu.co/sistemat02/sed/websubsidios/HORUS/Actas/stcae/validar.asp"
    #http://matriculabd1.redp.edu.co/sistemat02/sed/websubsidios/HORUS/Actas/stcae/acta.asp
    r = rq.post(url, data=data)
    html = bs(r.content,"html.parser")
    
    




i = 88468
while True:
    data = {
    "radicado":"{}".format(str(i))
        }
    #print i
    r = rq.post(url, data = data, headers=headers)
    html = bs(r.content, "html.parser")
    code =  str(r.status_code)
    #print i
    for dat in html.findAll("input",{"name":"nuid"}):
    
        
        try:
                
            a = dat["value"]
            print a
            validar(a)
                
            
        except:
            pass

            
    i = i + 1
        
