import requests as rq
from netaddr import *
from bs4 import BeautifulSoup
from requests.auth import HTTPBasicAuth
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()
global user, password
from urlparse import *


user = "ellipsys"
password = "5w0rdf15h"
file = open("shodan.txt","wb")
def resp(tag):
    for i in range(1,21):
        url = "https://www.shodan.io{}?page={}".format(tag,str(i))
        r = rq.get(url,auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
        html = BeautifulSoup(r.content, "html.parser")
        for search in html.find("div",{"class":"span8 browse-queries browse-queries-large"}).findAll("a"):
            link = str("https://www.shodan.io"+search["href"])
            if 
url = "https://www.shodan.io/explore/popular"
r = rq.get(url,auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
html = BeautifulSoup(r.content, "html.parser")
    
    
for search in html.find("div",{"class":"span3 hidden-phone"}).findAll("a"):
    #search = search.find_next_sibling()
    tag = str(search["href"])
    if "tag" in tag:
        print tag
        resp(tag)
    else:
        pass
    
