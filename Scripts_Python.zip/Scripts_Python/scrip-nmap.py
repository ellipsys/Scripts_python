import nmap

nm = nmap.PortScanner()
equipos =open("equipos.csv", "w")
for e in range(180,256):
    e = e + 1
    #181.143.3.206
    for l in range(142,256):
        l = l + 1
        for i in range(2,256):
            i = i + 1
            for s in range(200,256):
                s = s + 1
                ip  = str(e)+'.'+str(l)+'.'+str(i)+'.'+str(s)
                nm.scan(ip, "5900,5901")
                for host in nm.all_hosts():
                  print('----------------------------------------------------')
                  print('Host : %s (%s)' % (host, nm[host].hostname()))
                  print('State : %s' % nm[host].state())
                  for proto in nm[host].all_protocols():
                    print('----------')
                    print('Protocol : %s' % proto)
                    lport = nm[host][proto].keys()
                    lport.sort()
                    #print lport
                    for port in lport:
                      estado =nm[host][proto][port]['state']
                      equipos.write(str(ip)+'\n')
                      #print type(estado)
                      print ('port : %s\tstate : %s') % (port, estado)
                      if estado =='open':
                        equipos.write(str(ip)+'\n')

