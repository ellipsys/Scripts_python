import requests as rq
from bs4 import BeautifulSoup as bs
from urlparse import *
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()


headers = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 6.1; de; rv:1.9.2.3) Gecko/20121221 Firefox/3.6.8'}
i = 0
total = 0
url = 'https://duckduckgo.com/html/'
data = {
    'q':'site:edu.co index.of',
    't':"hd",
    'ia':'web',
    's':'0',
    'o':'x'
}
r = rq.get(url, params=data, headers=headers)
text = bs(r.content, "html.parser")
for result in text.find(id='links').findAll('a', {"class":"result__url"}):
    link =  result["href"]
    o = urlparse(link, "http")
    link = parse_qs(o.query)["uddg"][0]
    
    #print o.query
    print link

