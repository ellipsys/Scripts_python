import requests
import json
__autor__ = "Eliseo"

data = {
    'q': "country:co site:gov.co",
    'format':"json",
    'pretty':'1'
    
}
url = 'http://api.duckduckgo.com/?'
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}

r = requests.post(url, data=data, headers=headers)
print r.content