import requests as rq
from bs4 import BeautifulSoup as bs

url = "http://downvids.net/videoflv.php"
link = "http://downvids.net/"

rq = rq.Session()
r = rq.get(link)
html = bs(r.content, "html.parser")
token1 = html.find("input", {"name":"autoken"})["value"]
token2 = html.find("input", {"name":"authenticity_token"})["value"]
video = raw_input("Please enter link of youtube: ")
data = {
    "autoken":token1,
    "authenticity_token":token2,
    "arama":video,
    "hd":"4"
}
headers = {
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36"
}
r = rq.post(url, data=data, headers=headers)
html = bs(r.content, "html.parser")
name = html.find("span", {"class":"msgtxt en"}).text
file = html.find("a", {"class":"round more"})["href"]
result = open("%s.mp4"%(name),"wb")
print name 
print file
r = rq.get(str(file),verify=False, headers=headers)
#result.write(r.content)