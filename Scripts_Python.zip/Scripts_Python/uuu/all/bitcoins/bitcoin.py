import requests as rq
from bs4 import BeautifulSoup as bs
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()
from requests.auth import HTTPBasicAuth

url = "https://2captcha.com/cabinet"
#url = "https://2captcha.com/captcha3.php?client=3080195:2b553d4b5451273ca58227d32e8ed5c7&action=get"
headers = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 6.1; de; rv:1.9.2.3) Gecko/20121221 Firefox/3.6.8'}
cookies = {
    "Cookie":"PHPSESSID=oc26jgr0o0fpv5pfcfp7b22mc6", 
    "counter_user_id":"110379310",
    "reg_referer":"%7B%22referer%22%3Afalse%2C%22ip%22%3A%22181.54.153.14%22%2C%22uri%22%3A%22%5C%2F%3Ffrom%3D1920013%22%2C%22ref_id%22%3A%221920013%22%7D",
    "client":"3080195%3A2b553d4b5451273ca58227d32e8ed5c7", 
    "_ga":"GA1.2.1869772302.1486175616"
}
# auth=HTTPBasicAuth("eliseo.torres95@gmail.com", "5w0rdf15hcaptcha5w0rdf15h"),
r = rq.get(url,cookies=cookies, verify=False,headers=headers)
print r.status_code
print r.cookies
