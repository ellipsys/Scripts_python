# -*- coding: utf-8 -*-
import urllib
import requests as rq
from bs4 import BeautifulSoup as bs
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()


url = "http://www.biography.com/people?"
search = raw_input("Please name: ")

data = {
    "query":str(search)
    #"config":"published"
}

search = urllib.urlencode(data)
url = url + search
print url
r = rq.get(url)
html = bs(r.content, "html.parser")
#print html
for people in html.findAll("a"): #,{"class":"ng-binding ng-scope"}
    print people