try:
    # Python 2
    from urllib2    import urlopen
    from urllib     import urlencode
except:
    # Python 3
    from urllib.request     import urlopen
    from urllib.parse       import urlencode

# The simplejson library has better JSON-parsing than the standard library and is more often updated
from simplejson import dumps, loads



class WebAPI:
    """Wrapper around the SHODAN webservices API"""
    
    
   
    
    
    
    def __init__(self, key):
        """Initializes the API object.
        
        Arguments:
        key -- your API key
        
        """
        print('WARNING: This class is deprecated, please upgrade to use "shodan.Shodan()" instead of shodan.WebAPI()')
        self.api_key = key
        self.base_url = 'http://www.shodanhq.com/api/'
        
        
    
    def _request(self, function, params, service='shodan'):
        """General-purpose function to create web requests to SHODAN.
        
        Arguments:
        function  -- name of the function you want to execute
        params      -- dictionary of parameters for the function
        
        Returns
        A JSON string containing the function's results.
        
        """
        # Add the API key parameter automatically
        params['key'] = self.api_key
        
        # Determine the base_url based on which service we're interacting with
        base_url = {'shodan': self.base_url}.get(service, 'shodan')

        # Send the request
        try:
            data = urlopen(base_url + function + '?' + urlencode(params)).read().decode('utf-8')
        except:
            pass
        
        # Return the data
        return data
    
    
    
    def search(self, query, page=1, limit=None, offset=None):
        """Search the SHODAN database.
        
        Arguments:
        query    -- search query; identical syntax to the website
        
        Optional arguments:
        page     -- page number of the search results 
        limit    -- number of results to return
        offset   -- search offset to begin getting results from
        
        Returns:
        A dictionary with 3 main items: matches, countries and total.
        Visit the website for more detailed information.
        
        """
        args = {'q': query,'p': page,}
        if limit:
            args['l'] = limit
        if offset:
            args['o'] = offset
        
        return self._request('search', args)