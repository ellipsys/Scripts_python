# -*- coding: utf-8 -*-
import urllib
import requests
from bs4 import BeautifulSoup as bs
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()
global headers
import time

headers = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36"}
url_p = "https://www.youtube.com/results?"
link = "https://www.youtube.com"
filtrado = []

########################################################################################################### funcion 2

def search_fil(name_f,link_f,e):
    filtrado.append(link_f)
    try:
        print """%s - %s"""%(e,name_f)
    except:
        pass
    
############################################################################################################ funcion 4
def page_n(htm_2,n):
    for i in htm_2.findAll("div",{"class":"yt-lockup-content"}):
        try:
            page = "https://www.youtube.com"+str(htm_2.find("a", {"aria-label":"Go to page %s"%(n)})["href"])
            title_video = i.find("a")["title"].strip()
            link_video = str(i.find("a")["href"])###lin video
            duration = i.find("span").text.replace("- ","")
            chanel_link = i.find("a",{"class":"g-hovercard yt-uix-sessionlink spf-link "})["href"]
            chanel_name = i.find("a",{"class":"g-hovercard yt-uix-sessionlink spf-link "}).text
            time = i.find("ul").find("li").text
            view = i.find("ul").findNext("li").findNext("li").text#.contents[1]
            description = i.find("div",{"dir":"ltr"}).text
            print title_video
            print "https://www.youtube.com"+link_video
            print "https://www.youtube.com"+str(chanel_link)
            print chanel_name
            print duration.strip()
            print time.strip()
            print view.strip()
            print description[:45]
            print description[45:90]
            print description[90:].strip()
            print page
            print n
            print "############"*10
            
        except:
            pass

    try:
        n = n + 1
        inter(page,n)
    except:
        print "Termine"
####################################################################### funcion 5
def inter(page,n):
    r_2 = requests.get(page,timeout=None)
    html_2 = bs(r_2.content,"html.parser")
    page_n(html_2,n)

####################################################################### Inicio 1
search = raw_input("Input your search please: ")
data = {"search_query":"%s"%(search)}
data = urllib.urlencode(data)
url = url_p+data
print url
e = 0
r = requests.get(url,headers=headers)
html = bs(r.content, "html.parser")
for filt in html.find("div",{"id":"filter-dropdown"}).findAll("a"):
    name_f = filt.text
    link_f= filt["href"]
    search_fil(name_f,link_f,e)
    e = e + 1
##################################################################### funcion 3

num = raw_input("Enter the number of filter: ")

if len(num)==0:
    print "Anything number. Finding all"
    link = url
    print link
    time.sleep(6)
    r1 = requests.get(link)
    n = 2
    htm = bs(r1.content,"html.parser")
    page_n(htm,n)

else:
    num = int(num)
    link = link+filtrado[num]
    #print link
    r1 = requests.get(link)
    n = 2
    htm = bs(r1.content,"html.parser")
    page_n(htm,n)
