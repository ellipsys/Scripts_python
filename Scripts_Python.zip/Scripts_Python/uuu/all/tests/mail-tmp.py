# -*- coding: utf-8 -*-
import requests as rq
from bs4 import BeautifulSoup as bs
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()
import os

url = "https://www.mohmal.com/es"
choice = ["/create/random","/create","/extend","/logout","/change"]

headers = {
    "User-Agent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36"
}
s = rq.Session()

def create():
    
    try:
        domains = ["mohmal.in","mohmal.tech","mohmal.im","mohmal.com"]
        mail = raw_input("Please enter you nick name: ")
        domain = int(raw_input("""
    Please select the domain
    
    [1] - mohmal.in
    [2] - mohmal.tech
    [3] - mohmal.im
    [4] - mohmal.com
    
    >>> """))
        domain = domains[domain]
        print domain
    
        data = {
        "name":mail,
        "domain":domain
    }
        r = s.post(url+choice[1], headers=headers, data=data)
        print r.cookies
        l = "https://www.mohmal.com/es/view"
        r = s.get(l, headers=headers)
        html = bs(r.content, "html.parser")
    
        email = html.find("div",{"class":"email"}).text
        print "Email creado"
        print email
        r = s.get(url+choice[3], headers=headers)
        print "email eliminado"
    
    except:
        pass
    
    
def random():
    print "Me llamaron"
    r = s.get(url+choice[0], headers=headers)
    html = bs(r.content, "html.parser")
    email = html.find("div",{"class":"email"}).text
    print "This it the random email"
    print email
    

try:
        
    f = int(raw_input("""
    
        ┌┬┐┌─┐┌┬┐┌─┐┌─┐┬─┐┌─┐┬    ┌┬┐┌─┐┬┬  
         │ ├┤ │││├─┘│ │├┬┘├─┤│    │││├─┤││  
         ┴ └─┘┴ ┴┴  └─┘┴└─┴ ┴┴─┘  ┴ ┴┴ ┴┴┴─┘
    
        ####################################
        Please enter the option.
        
        [1] - Generate random email
        [2] - Write nick name email temporal 
        [q] - Quit
        
        >>> """))
    print f
    if f == 1:
        os.system("clear")
        random()
            
    elif f == 2:
        os.system("clear")
        create()
            
    elif str(f)=="q":
        os.system("clear")
        print "Quit the program"
        
        
except Exception as e:
    print e
    print "Quit the program"
        
    
    
def extend():
    pass

def logout():
    pass

def change():
    pass

    



