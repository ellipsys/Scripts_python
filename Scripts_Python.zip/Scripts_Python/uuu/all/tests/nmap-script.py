import nmap
from netaddr import *

net = open("emcali.txt", "wb")

nm = nmap.PortScanner()
for ip in IPNetwork("186.28/16"):
    ip = str(ip)

    s = nm.scan(ip, arguments= '-sL ')

    try:
    
        adr = s['scan'][ip]['hostnames'][0]['name']
        """
        if "emcali.net.co" in adr:
            #net.write(ip+"\n")
            print adr
        else:
            pass
        """
        print adr
    except:
        print "paila ni idea"