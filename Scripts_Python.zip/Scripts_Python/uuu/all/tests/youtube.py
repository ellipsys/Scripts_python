# -*- coding: utf-8 -*-
import urllib
import requests
from bs4 import BeautifulSoup as bs
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()
global headers

def page_n(html,n):
    for i in html.findAll("div",{"class":"yt-lockup-content"}):
        try:
            #page = "https://www.youtube.com"+str(html.find("a",{"class":"yt-uix-button vve-check yt-uix-sessionlink yt-uix-button-default yt-uix-button-size-default"})["href"])
            page = "https://www.youtube.com"+str(html.find("a", {"aria-label":"Go to page %s"%(n)})["href"])
            title = i.find("a")["title"].strip()
            link = str(i.find("a")["href"])
            duration = i.find("span").text.replace("- ","")
            chanel_link = i.find("a",{"class":"g-hovercard yt-uix-sessionlink spf-link "})["href"]
            chanel_name = i.find("a",{"class":"g-hovercard yt-uix-sessionlink spf-link "}).text
            time = i.find("ul").find("li").text
            view = i.find("ul").findNext("li").findNext("li").text#.contents[1]
            description = i.find("div",{"dir":"ltr"}).text
            print title
            print "https://www.youtube.com"+link
            print "https://www.youtube.com"+str(chanel_link)
            print chanel_name
            print duration.strip()
            print time.strip()
            print view.strip()
            print description[:45]
            print description[45:90]
            print description[90:].strip()
            print "###############################################"
            time.sleep(1)
            
        except:
            pass

    try:
        n = n + 1
        inter(page,n)
    except:
        print "Termine"
        

def inter(page,n):
    r = requests.get(page,timeout=None)
    html = bs(r.content,"html.parser")
    page_n(html,n)
 
    
n = 2    
url = "https://www.youtube.com/results?"
headers = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36"}
search = raw_input("Ingrese la palabra a buscar: ")
data = {"search_query":"%s"%(search)}
data = urllib.urlencode(data)
print url+data
r = requests.get(url+data,headers=headers)
html = bs(r.content, "html.parser")
page_n(html,n)



        
 

