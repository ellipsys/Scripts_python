import requests as rq
import urllib

url = 'https://api.shodan.io/shodan/host/search?key=SHbFGeiAsrfafHbf7ODilNk30cOcnxaQ&'
data = {
    "query":"country:co",
    "page":"1"
}
data = urllib.urlencode(data)
link = (url+data)
print link

