# -*- coding: utf-8 -*-
import urllib
import requests as rq
from bs4 import BeautifulSoup as bs
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()

send = open("banners.txt","rb")
print send

def upload(link, s):
    data = {
        "signature": s,
        "js_enabled":"1",
        "terms":"1",
        "upload_files":send,
        "file[]":"",
        "description[]":"",
        "upload_file[]":"",
        #"terms":"",
        "Content-Type": "text/plain",
        "recpemail":"",
        "ownemail":""
    }
    rs = f.post(link,data=data)
    print rs.content
    print rs.headers
    print rs.cookies
    print "Status upload %s"%(rs.status_code)
    result = bs(rs.content,"html.parser")
    for url in result.findAll("div",{"class":"urlbox small"}):
        print url["href"]
        
f = rq.Session()
url = "https://www.sendspace.com/"
headers = {"User-Agent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36"}

r = f.get(url,headers=headers)
html = bs(r.content,"html.parser")
for i in html.findAll("form",{"role":"main"}):
    link = str(i["action"])
    for l in i.findAll("input",{"name":"signature"}):
        s =  str(l["value"])
        print link
        print s
        upload(link, s)
        
        

    
        
    
