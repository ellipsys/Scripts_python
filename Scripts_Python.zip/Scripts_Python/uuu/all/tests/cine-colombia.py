# -*- coding: utf-8 -*-
import requests as rq
import urllib
from bs4 import BeautifulSoup as bs

url = "http://www.cinecolombia.com/cartelera/bogota"

r = rq.get(url)
html = bs(r.content,"html.parser")
for movie in html.find("div",{"class":"homescategorias-wrapper"}).findAll("a" ,{"class":"ver_mas"}): #.findAll("div",{"class":"item_pelicula"})
    try:
        
        link = movie["href"]
        r = rq.get(link)
        doc = bs(r.content,"html.parser")
        
        for info in doc.find("div",{"class":"box"}):
            
            #image = info.find("img")["src"]
            #print image
            
            #title = info.find("img")["title"]
            #print title
            #rating = info.find("span",{"class":"average-rating"}).text
            #print rating
            #title_o = info.find("div",{"class":"field field-name-field-titulo-original"})
            #estreno = info.find("div",{"class":"field field-name-field-fecha-estreno"})
            #print estreno
            #clasi = info.find("div",{"class":"clas-pr"})
            #print title
            #print str(clasi.text) + " hola"
            
            #sinopsis =  info.find("div",{"class":"field field-name-field-sinopsis"}).text
            #print sinopsis
            #duracion =  info.find("div",{"class":"field field-name-field-duracion"}).text
            #pais =  info.find("div",{"class":"field field-name-field-pais"}).text
            #reparto =  info.find("div",{"class":"field field-name-field-reparto"}).text
            
            #director =  info.find("div",{"class":"field field-name-field-director"}).text
            #print info
            #print "#############################################################################"
            pass
        for info in doc.find("div",{"class":"box"}).findNext("div",{"class":"box"}):
            #title_o = info.find("div", {"class":})
            #print title_o
            print info
            print "//////////////////////////////////////////////////////////////////////77"
            
    except:
        pass
