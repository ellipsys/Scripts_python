import requests as rq



#http://181.54.114.129/RgSwInfo.asp
url = raw_input("Ingrese ip ")
r = rq.get(url)
print "Headers: \t{}".format(str(r.headers))
print "Status code:\t{}".format(str(r.status_code))
