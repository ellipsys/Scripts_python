import requests as rq
from netaddr import *
from bs4 import BeautifulSoup as bs
from requests.auth import HTTPBasicAuth
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()
global user, password

user = "guest"
password = "guest"
data = {
    "username":"guest", #username
    "password":"guest"
}
headers = {
    "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Encoding":"gzip, deflate, sdch",
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36"

    
}
s = rq.Session()
r = rq.get("http://190.144.30.137/DataService_Wifi.html",data=data,headers=headers, timeout=None, verify=False)


#http://190.145.25.9/wifilan.htm System_WebPasswordSet.html Content-Length: 5106

html = bs(r.content, "html.parser")

#print html

for name in html.findAll("input",{"id":"txSSID1"}):
    print name["value"]


####################Content-Length: 5106
