import requests as rq
from netaddr import *
from bs4 import BeautifulSoup as bs
from requests.auth import HTTPBasicAuth

url = "http://181.55.198.76/wlanBasicSecurity.asp"

r = rq.get(url)
print r.headers
print r.status_code
print r.content