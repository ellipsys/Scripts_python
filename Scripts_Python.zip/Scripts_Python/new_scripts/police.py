#!/usr/bin/env python
# _*_ coding:utf-8 _*_
import requests as rq
import urllib
from bs4 import BeautifulSoup as bs
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()
import gspread
from oauth2client.service_account import ServiceAccountCredentials

scope = ['https://spreadsheets.google.com/feeds']
credentials = ServiceAccountCredentials.from_json_keyfile_name('redes.json', scope)
gc = gspread.authorize(credentials)
sht2 = gc.open_by_url('https://docs.google.com/spreadsheets/d/1Z_jNuJSl-UCOixHx29qzQapDCoeXwdW5WWRYEGfDci8/edit#gid=0')
worksheet = sht2.get_worksheet(0)


url = "https://www.policia.gov.co/file/"
server = "https://www.policia.gov.co/sites/default/files/"
i = 7416
row = 3090

while True:
    link = url+str(i)
    try:
        print link
        r = rq.get(link,timeout=None)
        html = bs(r.content, "html.parser")
        f = html.find("h1",{"class":"title"}).text.encode('ascii','ignore').encode('ascii','replace')
    #print f
        if f != "Pgina no encontrada":
        
            t = f.split(".")
            l = html.find("div",{"class":"region region-content clearfix"}).findNext()#region region-content clearfix
            print link

            try:
                try:
                    print row
                    j = html.find("div",{"class":"region region-content clearfix"}).findNext().find("a")["href"]
                    worksheet.update_acell('A%s'%(row), str(f))
                    worksheet.update_acell('B%s'%(row), str(link))
                    worksheet.update_acell('C%s'%(row), str(j))
                    worksheet.update_acell('D%s'%(row), str(t[-1:]))
                    print j
            
                except:
                    j = html.find("div",{"class":"region region-content clearfix"}).findNext().find("img")["src"]
                    print j
            
                    worksheet.update_acell('A%s'%(row), str(f))
                    worksheet.update_acell('B%s'%(row), str(link))
                    worksheet.update_acell('C%s'%(row), str(j))
                    worksheet.update_acell('D%s'%(row), str(t[-1:]))
            
            
            
            except:
                try:
                    j = html.find("div",{"class":"region region-content clearfix"}).findNext().find("source")["src"]
                    print j
            
                    worksheet.update_acell('A%s'%(row), str(f))
                    worksheet.update_acell('B%s'%(row), str(link))
                    worksheet.update_acell('C%s'%(row), str(j))
                    worksheet.update_acell('D%s'%(row), str(t[-1:]))
                
                except:
                    worksheet.update_acell('A%s'%(row), "Error")
                    worksheet.update_acell('B%s'%(row), str(link))
                    worksheet.update_acell('C%s'%(row), "Error")
                    worksheet.update_acell('D%s'%(row), "Error")
            
         
       """http://186.82.151.82:8080/greet.html
       http://200.21.45.38/download/Internal/201704/08
       http://200.12.181.7/"""
        
            print 10*"///"
            
        #print f.text
        
        else:
            pass
        
        row = row + 1
        
        
    except:
        
        pass
    
    i = i + 1
    