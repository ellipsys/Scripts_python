import requests as rq

url = "http://umb.edu.co/index.php?option=com_users&view=reset"#"http://media.umb.edu.co/wp-login.php?action=lostpassword"
url2= "http://umb.edu.co/index.php?option=com_users&view=remind"

payload = {
    "user_login":"http://media.umb.edu.co/wp-login.php?action=lostpassword",
    "redirect_to":"ellipsys95@gmail.com"
}

r1 = rq.get(url)
r = rq.get(url2)
print r.status_code
print r.headers