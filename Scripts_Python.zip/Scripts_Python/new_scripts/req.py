import requests as rq
from netaddr import *
import urllib
from bs4 import BeautifulSoup
from requests.auth import HTTPBasicAuth
global user, password

d = {
    "getpage":"html/index.html",
    "var:menu":"setup",
    "var:page":"wireless",
    "var:subpage":"wlsecurity" #wlbasic
}

url = "http://190.252.0.9:8000/cgi-bin/webproc?"
datos = {
    "SELECT_UserName":"support",
    "INPUT_Psd":"support"
}

data = urllib.urlencode(d)
f=url+data
print f
#http://190.252.0.9:8000/cgi-bin/webproc?getpage=html/index.html&var:menu=advanced&var:page=wadvance&var:subpage=wlsecurity
r = rq.post(f, data=datos)
print r.content
