import requests as rq
from bs4 import BeautifulSoup as bs
from requests.auth import HTTPBasicAuth
global user, password

user = "Customer"
password = "ClienteETB2006"


req = rq.get("http://190.24.0.191/status/status_deviceinfo.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
html = bs(req.content, "html.parser")
mac = html.find(text="MAC Address").findNext("td").findNext("td").text.strip() #{"class":"tabdata"},
print mac
r = rq.get("http://190.24.0.191/basic/home_wlan.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
h = bs(r.content, "html.parser")
ssid = h.find("input",{"name":"ESSID"})["value"].strip()
pss = h.find("input",{"name":"PreSharedKey"})["value"].strip()
if pss==None:
    print "Sin password"

print ssid
print pss
print mac
