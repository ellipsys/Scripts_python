import requests as rq

s = raw_input("Ip: ")
#r = rq.get(s)


h = s.startswith("http://")
if h == False:
    r = rq.get("http://"+s+":8000/cgi-bin/webproc")
    print r.headers
    print r.content
    
else:
    r = rq.get(s+":8000/cgi-bin/webproc")
    print r.headers
    print r.content
    