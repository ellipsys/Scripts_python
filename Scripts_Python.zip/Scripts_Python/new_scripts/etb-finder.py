import requests as rq
from netaddr import *
from bs4 import BeautifulSoup as bs
from requests.auth import HTTPBasicAuth
global user, password
import gspread
from oauth2client.service_account import ServiceAccountCredentials

scope = ['https://spreadsheets.google.com/feeds']
credentials = ServiceAccountCredentials.from_json_keyfile_name('redes.json', scope)
gc = gspread.authorize(credentials)
sht2 = gc.open_by_url('https://docs.google.com/spreadsheets/d/1KwC8Slsknhu47ttmkGH029g4YRZ7RHaWSgp3pv8DL6A/edit#gid=0')
worksheet = sht2.get_worksheet(0)
hosts = IPRange('186.28.240.13', '186.28.255.255')
addrs = list(hosts)
i = 36
user = "Customer"
password = "ClienteETB2006"
rq = rq.Session()
w300 = 'Basic realm="ZXV10 W300"'
w300E = 'Basic realm="ZXV10 W300E"'
huawei = 'Basic realm="EchoLife Home Gateway"'
hg530 = 'Basic realm="Home Gateway"'
tp_link = 'Basic realm="TD-W8951ND"'
devices = ['Basic realm="ZXV10 W300"','Basic realm="ZXV10 W300E"','Basic realm="EchoLife Home Gateway"','Basic realm="Home Gateway"','Basic realm="TD-W8951ND"']
def w300R(ip,i):
    o = 0
    code = ""
    while code != "200":
       req = rq.get(ip+"/basic/home_wlan.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False) 
       code = str(req.status_code)
       o = o + 1
       print code
       if code =="200" or o==8:
           break
    try:
        print ip
        worksheet.update_acell('A%s'%(i), ip[7:])
        worksheet.update_acell('E%s'%(i), "w300")
        req = rq.get(ip+"/status/status_deviceinfo.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
        print req.status_code
        html = bs(req.content, "html.parser")
        mac = html.find(text="MAC Address").findNext("td").findNext("td").text.strip() #{"class":"tabdata"},
        r = rq.get(ip+"/basic/home_wlan.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
        print r.status_code
        h = bs(r.content, "html.parser")
        ssid = h.find("input",{"name":"ESSID"})["value"].strip()
        pss = h.find("input",{"name":"PreSharedKey"})["value"].strip()
        
        worksheet.update_acell('B%s'%(i), ssid)
        worksheet.update_acell('C%s'%(i), pss)
        worksheet.update_acell('D%s'%(i), mac)
        
        print ssid
        print pss
        print mac
        print "////////////////////////////////////////////////////"
    except:
        print ""
        
def w300ER(ip,i):
    code = ""
    o = 0
    while code != "200":
       req = rq.get(ip+"/basic/home_wlan.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False) 
       code = str(req.status_code)
       o = o + 1
       print code
       if code =="200" or o ==8:
           break
    try:
        print ip
        worksheet.update_acell('A%s'%(i), ip[7:])
        worksheet.update_acell('E%s'%(i), "w300E")
        req = rq.get(ip+"/status/status_deviceinfo.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
        html = bs(req.content, "html.parser")
        mac = html.find(text="MAC Address").findNext("td").findNext("td").text.strip() #{"class":"tabdata"},
        print mac
        r = rq.get(ip+"/basic/home_wlan.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
        h = bs(r.content, "html.parser")
        ssid = h.find("input",{"name":"ESSID"})["value"].strip()
        pss = h.find("input",{"name":"PreSharedKey"})["value"].strip()
        worksheet.update_acell('A%s'%(i), ip[7:])
        worksheet.update_acell('B%s'%(i), ssid)
        worksheet.update_acell('C%s'%(i), pss)
        worksheet.update_acell('D%s'%(i), mac)
        
        print ssid
        print pss
        print mac
        print "////////////////////////////////////////////////////"
    except:
        print ""
    

    
def hg520R(ip,i):
    code = ""
    o = 0
    while code != "200":
       req = rq.get(ip+"/home_wlan.html",auth=HTTPBasicAuth(user, password), timeout=None, verify=False) 
       code = str(req.status_code)
       o = o + 1
       print code
       if code =="200" or o==8:
           break    
    
    try:
        worksheet.update_acell('A%s'%(i), ip[7:])
        worksheet.update_acell('E%s'%(i), "hg520")
        req = rq.get(ip+"/home_wlan.html",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
        source = bs(req.content, "html.parser")
        for red in source.find_all("input", {"name":"ESSID"}):
            ssid = str(red["value"])
            if ssid == "CPE-WI-FI_ETB":
                print str(ip)+" Free wifi \n//////////////////////////////////"
                worksheet.update_acell('A%s'%(i), ip)
                worksheet.update_acell('B%s'%(i), "free wifi")
                
            for clave in source.find_all("input", {"name":"PreSharedKey"}):
                pss = str(clave["value"])
                print str(ip)
                print ssid
                print pss ##pendiente mac address
                
                worksheet.update_acell('B%s'%(i), ssid)
                worksheet.update_acell('C%s'%(i), pss)
                
                print "////////////////////////////////////////////////////"
    except:
        print "jjjkjkjk"

    
def hg530R(ip,i):
    code = ""
    o = 0
    while code != "200":
       req = rq.get(ip+"/home_wlan.html",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
       o = o + 1
       code = str(req.status_code)
       print code
       if code =="200" or o==8:
           break
    
    try:
        worksheet.update_acell('A%s'%(i), ip[7:])
        worksheet.update_acell('E%s'%(i), "hg530")
        req = rq.get(ip+"/home_wlan.html",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
        rm = rq.get(ip+"/rpServiceStatus.html", auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
        html = bs(req.content, "html.parser")
        h = bs(rm.content, "html.parser")
        ssid = html.find("input",{"name":"ESSID"})["value"]
        pss = html.find("input",{"name":"PreSharedKey"})["value"]
        mac = h.find("td",{"class":"tablerowvalue", "colspan":"3"}).text.strip()
        
        worksheet.update_acell('B%s'%(i), ssid)
        worksheet.update_acell('C%s'%(i), pss)
        worksheet.update_acell('D%s'%(i), mac)
        
        print "////////////////////////////////////////////////////"
    except:
        print ""
    
def tplinkR(ip,i):
    code = ""
    o = 0
    while code != "200":
       req = rq.get(ip+"/basic/home_wlan.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
       o = o + 1
       code = str(req.status_code)
       print code
       if code =="200" or o==8:
           break
    
    try:
        worksheet.update_acell('A%s'%(i), ip[7:])
        worksheet.update_acell('E%s'%(i), "tp-link")
        req = rq.get(ip+"/basic/home_wlan.htm",auth=HTTPBasicAuth(user, password), timeout=None,  verify=False)
        source = bs(req.content, "html.parser")
        for red in source.find_all("input", {"name":"ESSID"}):
            ssid = str(red["value"])
            for clave in source.find_all("input", {"name":"PreSharedKey"}):
                pss = str(clave["value"])
                print str(ip)
                print ssid
                print pss ##pendiente mac address /status/status_deviceinfo.htm
                
                worksheet.update_acell('B%s'%(i), ssid)
                worksheet.update_acell('C%s'%(i), pss)
                
                print "////////////////////////////////////////////////////"
    except:
        print ""


for l in addrs:
    url = l.format()
    ip = "http://"+str(url)
    print ip
    
    try:
        worksheet.update_acell('F1', str(url))
        r = rq.get(ip, timeout=0.6)
        header = str(r.headers)
    
        if w300 in header:
            
            req = rq.get(ip+"/basic/wlan_simple.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
            
            print "Soy un w300 "+str(url)
            i = i + 1
            w300R(ip,i)
                
        elif w300E in header:
            
            print "Soy un w300E "+str(url)
            req = rq.get(ip+"/basic/wlan_simple.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
            i = i + 1    
            w300ER(ip,i)
                
        elif huawei in header:
            
            req = rq.get(ip+"/home_wlan.html",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
            print "Soy un huawei hg520 "+str(url) ##hg520b
            hg520R(ip,i)
                
        elif hg530 in header:
            
            req = rq.get(ip+"/home_wlan.html",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
            print "Soy un huawei hg530 "+str(url)
            i = i + 1
            hg530R(ip,i)
            
        elif tp_link in header:
            
            req = rq.get(ip+"/basic/home_wlan.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
            print "Soy un Tp-link "+str(url)
            i = i + 1
            tplinkR(ip,i)
        
            
            
    except:
        pass
        
        

print "Termine"