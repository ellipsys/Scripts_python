import requests as rq
from bs4 import BeautifulSoup as bs
from requests.auth import HTTPBasicAuth
global user, password

user = "Customer"
password = "ClienteETB2006"

req = rq.get("http://190.24.0.141/home_wlan.html",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
rm = rq.get("http://190.24.0.141/rpServiceStatus.html", auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
html = bs(req.content, "html.parser")
h = bs(rm.content, "html.parser")
ssid = html.find("input",{"name":"ESSID"})["value"]
pss = html.find("input",{"name":"PreSharedKey"})["value"]
mac = h.find("td",{"class":"tablerowvalue", "colspan":"3"}).text.strip()
print ssid
print pss
print mac
