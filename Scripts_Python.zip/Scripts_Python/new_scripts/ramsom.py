from Crypto.Cipher import DES

print "ok"

data = ""
x = "text.txt"
encryption = DES.new('12345678')
with open(x, 'rb') as file:
    
    data = file.read()
    file.close()
    with open(x, 'wb') as file:
        if (len(data) % 8 != 0):
            data += '.' * (8 - len(data) % 8)
            dataCrypt = encryption.encrypt(data)
            file.write(dataCrypt)
            file.close()
            
print "Termine"