import requests as rq
from netaddr import *
from bs4 import BeautifulSoup
from requests.auth import HTTPBasicAuth
global user, password

user = "admin"
password = "Edatel*1"

#https://190.109.179.56/html/advance.html#diagnose_tools  link mac

rq = rq.Session()
url = "https://190.109.179.56/html/advance.html#wlan"
jar = requests.cookies.RequestsCookieJar()
jar = jar.set('activeMenuID', 'homenetwork_settings', domain='httpbin.org', path='/cookies')
#=; activeSubmenuID=wlan
r = rq.get(url,auth=HTTPBasicAuth(user, password), timeout=None, verify=False)

print r.status_code
#print r.content
print r.cookies