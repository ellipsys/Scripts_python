import csv

r = open('db.csv', 'r')
f = csv.reader(r, delimiter=',')
j = list(f)
lista = []


l = '181.50.254.230'
if l not in j:
    print 'la ip %s no esta '%l
else:
    print 'la ip %s esta'%l
    
    