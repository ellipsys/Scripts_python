# -*- coding: utf-8 -*-
import requests
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup
import socket
import csv
import time

x = open('db.csv','r')
host = csv.reader(x, delimiter=',')
var =0


    
    
    
    
for row in host:
    
    for i in range(181,255):
    
    
        a = str(i)
        for j in range(50,255):
            b = str(j)
       
            for p in range(1,255):
                c = str(p)
                for u in range(0,255):
                    
                    d = str(u)
                    ip = str(i)+'.'+str(j)+'.'+str(p)+'.'+str(u)
                    a=row[0]
                    if a == ip:
                        print 'es igual....'+a+'..........'+ip
                        a = a + 1
                        
                        
                    else:
                        print 'difente....'+a+'..........'+ip
                        a = a + 1
                        
                    
                    
    """            
                    
    print str(a)
    wr = "181.50.28.5"
    if a == wr:
        print 'es igual....'+a+'..........'+wr
        row = row + 1
    
    else:
        print 'difente....'+a+'..........'+wr
        row = row + 1
        """
    














                
                
        

