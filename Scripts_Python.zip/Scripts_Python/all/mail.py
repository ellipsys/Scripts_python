import smtplib
import time
#https://accounts.google.com/DisplayUnlockCaptcha
i = 0
 
mail = smtplib.SMTP("smtp.gmail.com:587")
#mail = smtplib.SMTP("localhost", 1130)

mail.ehlo()
mail.starttls()
mail.login("ellipsys95","5w0rdf15h")
mail.ehlo()

while True:
    i =i + 1
    
    content = "Test "+str(i)

    mail.sendmail("lizethjvb@hotmail.com", "lizethjvb@hotmail.com",content)
    
    print 'mail sent '+str(i) 
    x = i % 87
    if x==0:
        
        #time.sleep(240)
        print 'Estoy esperando para que el servidor no me desconecte '
        time.sleep(230)
   
mail.close()
