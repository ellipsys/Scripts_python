import nmap
nm = nmap.PortScanner()
ip = '167.0.215.136'
s = nm.scan(ip, arguments= '-sL')
"""
for host in nm.all_hosts():
    print('Host : %s (%s)' % (host, nm[host].hostname()))
"""
try:
    
    print s['scan'][ip]['hostnames'][0]['name']

except:
    print "paila ni idea"