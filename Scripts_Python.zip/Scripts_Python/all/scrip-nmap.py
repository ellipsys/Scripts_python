import nmap
import json
import requests
import time

nm = nmap.PortScanner()
files =open("equipos.csv", "w")
api = "http://ip-api.com/json/"
for e in range(180,256):
    e = e + 1
    #181.143.3.206
    for l in range(142,256):
        l = l + 1
        for i in range(6,256):
            i = i + 1
            for s in range(0,255):
                s = s + 1
                ip  = str(e)+'.'+str(l)+'.'+str(i)+'.'+str(s)
                nm.scan(ip, arguments="-p 102")
                
                try:
                  for host in nm.all_hosts():
                    x = nm[host].state()
                  
                    
                    print('Host : %s ' % (host))#nm[host].hostname()))
                    print('State : %s' % x)
                except requests.exceptions.Timeout:
                  time.sleep(300)
                  for proto in nm[host].all_protocols():
                    print('----------')
                    print('Protocol : %s' % proto)
                    lport = nm[host][proto].keys()
                    lport.sort()
                    #print lport
                    for port in lport:
                      estado =nm[host][proto][port]['state']
                      files.write(str(ip)+'\n')
                      #print type(estado)
                      print ('port : %s\tstate : %s') % (port, estado)
                      if estado =='open':
                        files.write(str(ip)+'\n')
                        

