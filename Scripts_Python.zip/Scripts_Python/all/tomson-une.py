#/cgi/b/_wli_/dt/ http://190.250.40.216/cgi/b/_wli_/dt/
import requests
#from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup
import socket


for i in range(198,255):
    i = i + 1
    c = str(i)
    for j in range(249,255):
        j = j + 1
        l=str(j)
        for p in range(39,255):
            p = p + 1
            m = str(p)
            for a in range(215,255):
                a = a + 1
                g = str(a)
                ip = c + "." + l + "." + m + "." + g
                try:
                    
                    r = requests.get("http://"+ip, timeout=0.3)
                    print 'probando '+ip
                    x= r.content
                    print r.status_code
                    bs = BeautifulSoup(x, "html.parser")
                    print bs
                    for a in bs.find_all("td", {"colspan":"3"}):
                        
                        print a.text
                except:
                    pass