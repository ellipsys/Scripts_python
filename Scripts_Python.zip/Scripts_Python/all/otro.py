import requests
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup

ip = raw_input('ingrese la ip: \n')
try:
    r = requests.get('http://'+ip+':80/basic/home_wlan.htm', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=None)
    print r.status_code
    

except:
    print 'ocurrio un error'