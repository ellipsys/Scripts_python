import csv

c = open('db.csv', 'r')

f = csv.reader(c)

lista = list(f)
linea = lista[-1:][0:]

k = linea[0][0]
ip = str(k)
print type(ip)
print ip

