import time

o = 7
p = 8
q = 6
r = 8
for i in range(o, 11):
    if i==10:
        o = 0
    else:
        for u in range(p,11):
            if u == 10:
               p = 0
            else:
                for j in range(q,11):
                    if j == 10:
                        q = 0
                    else:
                        for k in range(r,11):
                            if k == 10:
                                r = 0
                            else:
                                ip = str(i)+'.'+str(u)+'.'+str(j)+'.'+str(k)
                                print 'esta es la ip generada %s' %ip
                                time.sleep(1)
                                
                
    

    
