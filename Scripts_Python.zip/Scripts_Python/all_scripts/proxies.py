# -*- coding: utf-8 -*-
import requests as rq
import json
from bs4 import BeautifulSoup as bs
global headers, rq

__author__ = "Eliseo Torres"
"""https://www.exploit-db.com/papers/?l=1"""
headers = {"user-agent":"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"}
url = "http://proxy-list.org/spanish/search.php?search=&country=any&type=any&port=any&ssl=any"
rq = rq.Session()

def get_html(proxy):
    print proxy
    page = 1
    url = "https://www.exploit-db.com/papers/?pg=%s"%(page)
    r = rq.get(url, proxies=proxy,verify=False,headers=headers)
    html = bs(r.content, "html.parser")
    table = html.find("tbody")
    for title in table.findAll("td",{"class":"description"}):
        link = title.find("a")["href"]
        title = title.text.strip()
        print title
        print link
        print "*********"*10
    

def get_proxy(url):
    r = rq.get(url,verify=False)
    
    proxy = { "http" : "111.23.10.28:80"}
    get_html(proxy)


get_proxy(url)