# -*- coding: utf-8 -*-
#segmento de 186
import requests as rq
#country:CO org:"Movistar Colombia" title:" + gVarLogin + " port:"8000"

print "hola"
r = rq.get("http://186.119.192.20:8000")

print r.headers