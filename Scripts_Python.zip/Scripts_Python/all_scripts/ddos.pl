#!/usr/bin/perl

################################################################################
#                   Author: chort http://www.SMTPS.net/                        #
################################################################################

use strict;

my $time_str		= localtime(time);
my ($time_tmp, $tmp)	= split(':', $time_str);
my ($d, $m, $md, $hr)	= split(' ', $time_tmp);
my ($d, $m, $md, $hr)   = split(' ', $time_tmp);
if ( $md < 10 ) {
        $md = ' ' . $md;
}
my $time_prefix		= $m . ' ' . $md . ' ' . $hr;
my $logfile		= '/var/log/daemon';
my $evil_str		= '\.\/NS\/IN';
my %victims;
my @report;
my $line;

# http://www.perlmonks.org/?node_id=396001 -- thanks Dietz!!!
my $range = qr/
(
 (?:                               # first 3 octets:
  (?: 2(?:5[0-5]|[0-4][0-9])\. )   # 200 - 255
  |                                # or
  (?: 1[0-9][0-9]\. )              # 100 - 199
  |                                # or
  (?: (?:[1-9][0-9]?|[0-9])\. )    # 0 - 99
 )
 {3}                               # above: three times
 
(?:                                # 4th octet:
 (?: 2(?:5[0-5]|[0-4][0-9]) )      # 200 - 255
  |                                # or
 (?: 1[0-9][0-9] )                 # 100 - 199
  |                                # or
 (?: [1-9][0-9]?|[0-9] )           # 0 - 99
)
 
)
/x;

die 'Couldn\'t open '. $logfile . ': ' . $! . "\n" unless
			open(LOGFILE, '<', $logfile);

while (defined ($line = <LOGFILE>)) {
	if ($line =~ /^$time_prefix/) {
		if ($line =~ /$evil_str/) {
			if ($line =~ /^.+?($range).+$/) {
				$victims{$1}++;
			}	
		}
	}
}

close(LOGFILE);

while (my($k, $v) = each(%victims)) {
	push(@report, $v . ' ' . $k . "\n");
}

if (defined($report[0])) {
	print 'Queries for root (probable DNS amplification attacks AGAINST' .
          ' these IPs' . "\n";
	foreach(sort {$b <=> $a} @report) {
		print;
	}
}
