# -*- coding: utf-8 -*-
import requests as rq
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup as BS
import os
import gspread
import subprocess
from oauth2client.service_account import ServiceAccountCredentials
global user, password,header

rang = "186.85.74.*"

ips = subprocess.check_output("sudo nmap -Pn %s -p8080 --open | awk '/is up/ {print up}; {gsub (/\(|\)/,\"\"); up = $NF}'" %(rang),shell=True)
for ip in ips.splitlines():
    
    url = "http://%s:8080"%(ip)
    r = rq.get(url)
    code = str(r.status_code)
    
    if code=="401":
        print "ip: %s, Device:Techicolor"%(ip)
        
    
    