# -*- coding: utf-8 -*-
import requests as rq
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup as BS
import gspread
from oauth2client.service_account import ServiceAccountCredentials
global user, password,header
import subprocess

pay = {
    "SELECT_UserName":"support",
    "INPUT_Psd":"support"
}


header = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
#181.52.82.215 181.54.153.14 http://186.87.3.237:8080/wlanRadio.asp 180-50 http://181.50.1.32:8080/wlanPrimaryNetwork.asp<<<< escanear esto http://181.63.15.177:8080/wlanGuestNetwork.asp
scope = ['https://spreadsheets.google.com/feeds']
credentials = ServiceAccountCredentials.from_json_keyfile_name('redes.json', scope)
gc = gspread.authorize(credentials)
sht2 = gc.open_by_url('https://docs.google.com/spreadsheets/d/1-aJNoOTOYYBrvzdUpXGZjrj44FbEDlZVHPWCJOoMzBE/edit#gid=0')
worksheet = sht2.get_worksheet(0)
user = "support"
password = "support"
rq = rq.Session()
row = 0
for last in range(0,256):
    rang = "167.0.%s.*"%(last)
    ips = subprocess.check_output("sudo nmap -Pn %s -p8000 --open | awk '/is up/ {print up}; {gsub (/\(|\)/,\"\"); up = $NF}'" %(rang),shell=True)
    for ip in ips.splitlines():
        ip = str(ip)
        url = "http://%s:8000/cgi-bin/webproc"%(ip)
        try:
            r = rq.get(url,timeout=1, headers=header)
            #print r.status_code
            
        except:
            pass
        
        
        
        if "sessionid" in str(r.headers):
            
            
            try:
                print url
                html = BS(r.content, "html.parser")
                title = html.find("title").text
                print title
                #r = rq.post(url, data=pay)
                #print r.content
                worksheet.update_acell('A%s'%(row), url)
                worksheet.update_acell('B%s'%(row), str(title))
                print "*****"*10
            except:
                pass
            
            row = row + 1
