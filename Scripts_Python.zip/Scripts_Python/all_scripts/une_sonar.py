# -*- coding: utf-8 -*-
import requests as rq
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup as BS
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import subprocess

rang = "181.128.34.*"
    #print rang
ips = subprocess.check_output("sudo nmap -Pn %s -p80 --open | awk '/is up/ {print up}; {gsub (/\(|\)/,\"\"); up = $NF}'" %(rang),shell=True)
for ip in ips.splitlines():
    ip = "http://%s:80"%(ip)
        #181.128.99.209
    try:
        print ip
        r = rq.get(ip, timeout = 1)
        print r.status_code
        html = str(r.content)
        if "Thomson Gateway" in html:
            print ip
    except:
        pass
