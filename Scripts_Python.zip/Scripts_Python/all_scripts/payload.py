# -*- coding: utf-8 -*-
import requests as rq
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup as BS
import gspread
from oauth2client.service_account import ServiceAccountCredentials
rq = rq.Session()
user = "admin"
password = "Uq-4GIt3M"
scope = ['https://spreadsheets.google.com/feeds']
credentials = ServiceAccountCredentials.from_json_keyfile_name('redes.json', scope)
gc = gspread.authorize(credentials)
sht2 = gc.open_by_url('https://docs.google.com/spreadsheets/d/1qwsj2-11In_rmc_Fpt9oj-RWFpaNWgp33D15RWC15wY/edit#gid=0')
worksheet = sht2.get_worksheet(0)
row = 1
ip = worksheet.acell('A%s'%(row)).value
print ip

login = HTTPBasicAuth(user, password)
r = rq.get('http://%s:8080/wlanPrimaryNetwork.asp'%(ip), auth=login, timeout=1.5)
html = BS(r.content, "html.parser")
csr = str(html.find("input", {"name":"CSRFValue"})["value"])
url = "http://%s:8080/goform/wlanPrimaryNetwork?5G"%(ip)
####################3Name network
payload = {
"CSRFValue":csr,
"PrimaryNetworkEnable":"1",
"ServiceSetIdentifier":"Eliseo Torres",
"ClosedNetwork":"0",
"ApIsolate":"0",
"WpaPskAuth":"0",
"Wpa2PskAuth":"1",
"WpaEncryption":"3",
"WpaPreSharedKey":"5w0rdf15h",
"ShowWpaKey":"0x01",
"WpaRekeyInterval":"0",
"GenerateWepKeys":"0",
"WepKeysGenerated":"0",
"commitwlanPrimaryNetwork":"1",
"AutoSecurity":"1"
}
r = rq.post(url,auth=login, data=payload)
print r.status_code
print r.content