# -*- coding: utf-8 -*-
import requests as rq
from bs4 import BeautifulSoup as BS

site="http://ebookstore.iexplo1t.com/"
r = rq.get(site)
html = BS(r.content, "html.parser")
url = []
j = []
for link in html.findAll("a"):
    try:
        link = link["href"]
        if link.startswith("http://ebookstore.iexplo1t.com/2016"):
            if link not in url:
                
                url.append(link)
    except:
        pass

for i in url:
    #print i
    r = rq.get(i)
    html = BS(r.content, "html.parser")
    
    for link in html.findAll("a"):
        try:
            link = link["href"]
            if link.startswith("http://ebookstore.iexplo1t.com/2016"):
                if link not in url:
                
                    j.append(link)
                    print link
        except:
            pass
        
for p in j:
    print p