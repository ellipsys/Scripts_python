import requests as rq
from bs4 import BeautifulSoup as bs
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()
import time

def get_email():
    url = "https://10minutemail.com/10MinuteMail/index.html?dswid=2542"
    #class="gonderen"
    s = rq.Session()
    r = s.get(url)
    html = bs(r.content, "html.parser")
    for address in html.findAll("input",{"id":"mailAddress"}):
        email = address["value"]
        print "Tu email es "+email
        cookies = r.cookies
        refresh(cookies, url, email)
        
def refresh(cookies, url, email):
    i= 0
    while True:
        r = rq.get(url, cookies=cookies)
        html = bs(r.content, "html.parser")
        for count in html.findAll("span",{"id":"totalMessageCount"}):
            count = int(count.text)
            print count
            if count > 0:
                source = html.find("span",{"class":"inc-mail-address"})
                asunto = html.find("span",{"class":"inc-mail-subject"})
                hora = html.find("span",{"class":"inc-mail-date"})
                body = html.find("div",{"dir":"ltr"}) #dir="ltr"
                print "Origen: "+str(source)
                print "Asunto: "+str(asunto)
                print "Fecha: "+str(hora)
                print "Content-body: "+str(body)
                
            else:
                pass
        time.sleep(5)
        i = i + 1
        
    
        
get_email()