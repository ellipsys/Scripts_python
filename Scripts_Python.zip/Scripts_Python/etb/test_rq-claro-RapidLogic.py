import requests as rq
from netaddr import *
from bs4 import BeautifulSoup
from requests.auth import HTTPBasicAuth
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()
global user, password

user = "guest"
password = "guest"
gateway = 'RapidLogic/1.1'
##http://190.144.46.161 190.145.25.9
#network.htm mac
routers = open("routers.txt","wb")

for url in IPNetwork("190.85.0.0/20"):
    
    ip = "http://"+str(url)
    #print ">>> GET "+str(url)
    #w300E(ip)
    try:
        r = rq.get(ip, timeout=0.5, verify=False)
        head_device = str(r.headers)
        if gateway in head_device:
        
            code = str(r.status_code)
            if code == "200":
                print ip+" [+] Vulnerable"
                routers.write(str(ip)+"\n")
            else:
                pass
        else:
            pass
        
    except:
        pass