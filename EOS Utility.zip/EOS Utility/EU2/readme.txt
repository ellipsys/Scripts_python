﻿----------------------------------------------------------------------------
               Canon Utilities EOS Utility
                         Archivo LÉAME           

                          Versión 2.14
----------------------------------------------------------------------------
               Copyright (C) CANON INC 2014
____________________________________________________________________________

Gracias por comprar una cámara Canon.

La aplicación EOS Utility es un elemento de software utilizado para ajustar su 
cámara Canon y transferir imágenes desde ella.

Este archivo Léame ofrece la información más reciente acerca de utilidades de 
Canon EOS Utility.
Léalo antes de utilizar EOS Utility.
____________________________________________________________________________

--------
Índice
--------
1. Formatos de archivo compatibles con EOS Utility
2. Notas sobre la conexión a cámaras Canon
3. Notas sobre la carga de imágenes
4. Notas sobre cambio rápido de usuarios en Windows
5. Notas sobre la grabación de vídeo


1. Formatos de archivo compatibles con EOS Utility
===================================================
EOS Utility admite los siguientes formatos de archivo de imagen.
- Archivos de imágenes realizadas con una cámara Canon
- Imágenes JPEG conformes con el estándar DCF


2. Notas sobre la conexión a cámaras Canon
===========================================
(1) No desconecte la tarjeta de memoria o la batería, ni desconecte el cable de 
comunicación, durante la transmisión de datos entre EOS Utility y la cámara 
digital Canon, pues esto puede provocar un fallo de funcionamiento, según el PC 
que esté utilizando.

(2) No permita que el PC entre en modo de espera cuando la cámara Canon esté 
conectada al puerto USB del PC. Si el PC entra en modo de espera cuando la 
cámara Canon esté conectada al puerto USB del PC, salga del modo de espera sin 
desconectar el cable del PC. Si el cable se desconecta estando en modo de espera, 
puede no ser posible salir del modo de espera, según el modelo de PC. Para más 
detalles sobre el modo de espera, consulte el manual de funcionamiento de su PC.

(3) La cámara no puede comunicarse con varios programas de software a la vez. 
Asegúrese de que solamente hay un programa de software funcionando durante la 
transferencia de datos con la cámara.


3. Notas sobre la carga de imágenes
====================================
(1) Cuando cargue imágenes en su PC con EOS Utility, asegúrese de comprobar 
antes que hay espacio de almacenamiento suficiente en el disco o en el disco duro 
donde se van a guardar. Si intenta cargar imágenes sin disponer de suficiente 
espacio para guardarlas, la transferencia de imágenes podría interrumpirse a la 
mitad y no cargarse correctamente.

(2) No manipule la cámara durante los disparos con el intervalómetro.


4. Notas sobre cambio rápido de usuarios en Windows 
==================================================
No utilizar cambio rápido de usuario mientras se use EOS Utility.
EOS Utility podría no funcionar de la forma prevista.

5. Notas sobre la grabación de vídeo
=====================================
Es posible que el tiempo de grabación que se muestra en la Ventana de visión 
directa remota no coincida con el tiempo de grabación que se muestra en el monitor 
LCD de la cámara. El tiempo de grabación real es el tiempo que se muestra en el 
monitor LCD de la cámara. Utilice el tiempo que se muestra en la Ventana de visión 
directa remota solamente como un valor aproximado.

<ES><EOF>
