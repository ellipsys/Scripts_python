.. Wifiphisher documentation master file, created by
   sphinx-quickstart on Wed Mar 15 18:38:21 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Wifiphisher's documentation!
=======================================

Table Of Contents
-------------------

.. toctree::
   :maxdepth: 2

   getting_started.rst
   users_guide.rst
   api.rst
   faq.rst
   phishing_scenarios.rst
   modules.rst



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
