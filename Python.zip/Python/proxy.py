# -*- coding: utf-8 -*-
import requests as rq
import json
from bs4 import BeautifulSoup as bs
global headers, rq

__author__ = "Eliseo Torres"

"""https://www.exploit-db.com/papers/?l=1'/n'"""
headers = {"user-agent":"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"}
"""http://proxy-list.org/spanish/search.php?search=&country=any&type=any&port=any&ssl=any"""
url = "http://gimmeproxy.com/api/getProxy?anonymityLevel=1"
rq = rq.Session()
file = open("proxies.txt","a")
def get_html(proxy):
    print proxy
    page = 1
    url = "https://www.exploit-db.com/papers/?pg=%s"%(page)
    r = rq.get(url, proxies=proxy,verify=False,headers=headers)
    html = bs(r.content, "html.parser")
    table = html.find("tbody")
    for title in table.findAll("td",{"class":"description"}):
        link = title.find("a")["href"]
        title = title.text.strip()
        print title
        print link
        print "*********"*10
    

def get_proxy(url):
    #proxy = {"https":"socks5://177.142.203.27:15924"}
    while True:
        proxy = {'http': '177.67.83.194:80'}
        try:
            
            
            r = rq.get(url,verify=False,headers=headers,proxies=proxy)
            #print r.content
    
            data = json.loads(r.content)
            ip = data["ipPort"]
            proto = data["protocol"]
            proxy = { str(proto) : str(ip)}
            file.write(str(proxy)+'\n')
            proxy = proxy
            print proxy
        
        except:
            r = rq.get("http://ipinfo.io/json",verify=False,headers=headers,proxies=proxy)
            print r.content
            print "Sorry no work :("
            
            break
    
    #proxy = { "http" : "111.23.10.28:80"}
    #get_html(proxy)


get_proxy(url)