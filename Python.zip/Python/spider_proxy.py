# -*- coding: utf-8 -*-
import requests as rq
import json
from bs4 import BeautifulSoup as bs
global headers, rq

__author__ = "Eliseo Torres"

"""https://www.exploit-db.com/papers/?l=1'/n'"""
headers = {"user-agent":"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"}
"""http://proxy-list.org/spanish/search.php?search=&country=any&type=any&port=any&ssl=any"""
url = "http://gimmeproxy.com/api/getProxy?anonymityLevel=1"
rq = rq.Session()
def get_proxy(url):
    while True:
        proxy ={'': ''}
        try:
            
            proxy = {'http': '117.143.109.166:80'}
            r = rq.get(url,verify=False,headers=headers,proxies=proxy)
            #print r.content
    
            data = json.loads(r.content)
            ip = data["ipPort"]
            proto = data["protocol"]
            proxy = { str(proto) : str(ip)}
            file.write(str(proxy)+'\n')
            proxy = proxy
            print proxy
        
        except:
            r = rq.get("http://ipinfo.io/json",verify=False,headers=headers,proxies=proxy)
            print r.content
            print "Sorry no work :("
            
            break
        
get_proxy(url)
    