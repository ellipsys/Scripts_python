# -*- coding: utf-8 -*-
import requests as rq
import json
import base64
global headers, rq

file = open("85.txt", "rb")
en = base64.b64encode(file.read())

p = {
  "message": "my commit first",
  "committer": {
    "name": "Eliseo Torres",
    "email": "eliseo.torres95@gmail.com"
  },
  "content": en
}

rp = rq.put('https://api.github.com/repos/ellipsys/page/contents/game', auth=('ellipsys', '5w0rdf15h'),data=p)
print rp.status_code
print rp.content
print en