import subprocess
import metadata
"""
f_name = '/home/ubuntu/workspace/anexo9_ip_medicamentos_20090518.xls'
xls = open(f_name, "rb")
data = metadata.extract(xls)

for i in data:
    j = data[str(i)]
    print "%s: %s"%(i,j)
"""
out = subprocess.check_output("wget https://raw.githubusercontent.com/yantisj/tcpping/master/tcpping.py", shell=True)
print out