import requests
from bs4 import BeautifulSoup as bs
import urllib

def search(query):
    headers = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36"}
    query = urllib.urlencode(query)
    link = "https://www.ahmia.fi/search/?"+query
    print link
    try:
        r = requests.get(link,headers=headers,verify=False)
        html = bs(r.content,"html.parser")
        #print html
        for l in html.findAll("li",{"class":"result"}):
           title = str(l.find("h4").text)
           
           print "Title: %s,\nLink: %s"%(title.strip(),l["href"])
        
           print "******************"*5
    except:
        pass

query = raw_input("Search: ")
query = {"q": query}
search(query)

    
    
    