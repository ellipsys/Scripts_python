import sys
import json
import urllib
import subprocess
import requests as rq
from bs4 import BeautifulSoup as bs

rq = rq.Session()
class spider:
    
    def __init__(self):
        self.init()
        #self.q = urllib.urlencode({"q":query})
        self.proxy = None
        self.url = "http://gimmeproxy.com/api/getProxy?protocol=http"#"http://gimmeproxy.com/api/getProxy?anonymityLevel=1"
        self.google = "https://www.google.com.co/#q=site:unal.edu.co+%2Bext:pdf&start=0"
        self.headers = {"user-agent":"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"}
        
    
    def get_proxy(self):
        r = rq.get(self.url,headers=self.headers)
        try:
            data = json.loads(r.content)
            ip = data["ipPort"]
            proto = data["protocol"]
            self.proxy = { str(proto) : str(ip)}
            return self.proxy
        except:
            print "Sorry error"
            
    def search(self):
        proxies = self.get_proxy()
        print proxies
        r = rq.get(self.google,timeout=None,proxies=proxies)
        html = bs(r.content, "html.parser")
        for links in html.findAll("div",{"class":"srg"}):
            
            for link in links.finAll("cite",{"class":"_Rm"}):
                print link
   
        
    def init(self):
        
        print     """
        This is it a fuck test
        """






if __name__ == '__main__':
    eli = spider()
    try:
        eli.search()
    except:
        pass